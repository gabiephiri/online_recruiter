 
<?php include("includes/load.php");

$all_jobs = find_all_jobs();
$page_title = 'View & Apply for Jobs';
 ?>
  <?php
 if(isset($_POST['submit_user'])){
   $req_field = array('first_name', 'last_name', 'username', 'email_address', 'phone_number', 'department', 'user_group');
   validate_fields($req_field);
   $first_name = remove_junk($db->escape($_POST['first_name']));
   $last_name = remove_junk($db->escape($_POST['last_name']));
   $other_names = remove_junk($db->escape($_POST['other_names']));
   $title = remove_junk($db->escape($_POST['title']));
   $username= remove_junk($db->escape($_POST['username']));
   $email_address = remove_junk($db->escape($_POST['email_address']));
   $phone_number = remove_junk($db->escape($_POST['phone_number']));
   $department = remove_junk($db->escape($_POST['department']));
   $user_group = remove_junk($db->escape($_POST['user_group']));
  
   
   //create default password as a hash of first letter of lastname and full firstname
   
   $lower_surname = strtolower($last_name);
    $password = sha1($lower_surname);
   //end password creation 
   
   if(empty($errors)){
      $sql  = "INSERT INTO users (title, first_name, last_name, other_names, username, email_address, password, phone_number, department, user_level)";
      $sql .= " VALUES ('{$title}','{$first_name}', '{$last_name}', '{$other_names}','{$username}', '{$email_address}', '{$password}','{$phone_number}', '{$department}', '{$user_group}')";
      if($db->query($sql)){
		  insert_act('user', 'added', '1');
        $session->msg("s", "Successfully added user");
        redirect('manage_users.php',false);
      } else {
		  		  insert_act('user', 'added', '0');

        $session->msg("d", "Sorry failed to create user.");
        redirect('manage_users.php',false);
      }
   } else {
     $session->msg("d", $errors);
     redirect('manage_users.php',false);
   }
 }
?>
    <?php
	include('general_header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header">
       <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Candidate</a>
            </li>
            <li class="breadcrumb-item active">Jobs</li>
			<li class="breadcrumb-item active">All Jobs</li>
			<li class="breadcrumb-item active">Info &amp; Apply</li>

			
          </ol>
		</div>
        <div class="row">		
		 <div class="col-md-7 view-jobs">
            <table class="table table-striped" id = "dataTable" cellspacing = "0">
             <tr>
                </tr>
              </tfoot>
              <tbody>
			  <?php
	  
	  foreach ($all_jobs  as $a_job): 
	  if (is_job_active($a_job['id'])):
	  
	  ?>
   
		<tr class='prev view-button' id="pre<?php echo $a_job['id']?>" did='<?php echo $a_job['id']?>'>
      <td><?php echo count_id() ?></td>
       <td><?php echo $a_job['agentCount']. ' '.$a_job['title'].'s wanted at '. $a_job['location']. ' in '.$a_job['districtName'].'. Deadline: '.read_date($a_job['deadline']);?> </td>
		
        
		<td>
</td>
         </tr>
		 <?php endif; ?>
	<?php endforeach; ?>

			  
		
			  
			  </tbody>		
         </table>

          </div>

          <div class="col-md-5 viewemployee" style="display:none;"></div>

         
		  </div>
		  
        </div>
      </div>
	  </div>
	  </div>

    </div><!-- /.container -->
 
          

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   <script> 
      $(document).ready(function(){

        $(document).on('click', '.view-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("did"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "job_info_candidate.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		
		
		  //View Employee
        $(document).on('click', '.edit-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("xid"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "edit_user.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		

		 function deleteUser(x){
           sweetAlert({   title: "Proceed to delete user?!",
                                text: "user account will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_user.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } 
										  
					});
		
		 

		 }
		
		
		


        /**Delete Employee
        $(document).on('click', '.delete-button', function(){ 
          var eid = $(this).attr("did"); 
          var Data = {'eid':eid};
          $('#pre'+eid).hide(1000);
          $.ajax({
            url: "delemployee.php",
            method: "get",
            data: Data,
            // dataType: "text",
            success: function(response){
            }
          })
        });
		**/
		
	
	 $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
	 });


      });
    </script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	
	<script type="text/javascript">
function deleteUser(x){
sweetAlert({   title: "Proceed to delete user?!",
                                text: "user account will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_user.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } });
}
</script>
  </body>
  
</html>
