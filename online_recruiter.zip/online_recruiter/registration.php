<?php 
require_once ('includes/load.php');
$page_title = 'Create User';
 $all_ug = find_all('user_groups');
 $all_dept = find_all('departments');
 ?>

 <?php
 if(isset($_POST['register'])){
   $req_field = array('first_name', 'last_name', 'gender', 'age', 'location', 'district', 'email_address', 'phone_number', 'postal_address', 'username', 'password');
   validate_fields($req_field);
   

   $first_name = remove_junk($db->escape($_POST['first_name']));
   $last_name = remove_junk($db->escape($_POST['last_name']));
   $other_names = remove_junk($db->escape($_POST['other_names']));
   $gender = remove_junk($db->escape($_POST['gender']));
   $age = remove_junk($db->escape($_POST['age']));
   $location= remove_junk($db->escape($_POST['location']));
   $district = remove_junk($db->escape($_POST['district']));
   $email_address = remove_junk($db->escape($_POST['email_address']));
   $phone_number = remove_junk($db->escape($_POST['phone_number']));
   $postal_address = remove_junk($db->escape($_POST['postal_address']));
   $username = remove_junk($db->escape($_POST['username']));
   $text_password = remove_junk($db->escape($_POST['password']));
   $password = sha1($text_password); //encrypt password
 
   
   if(empty($errors)){
      $sql  = "INSERT INTO candidates (first_name, last_name, other_names, gender, age,  location, district, email_address,  phone_number, postal_address, username, password)";
      $sql .= " VALUES ('{$first_name}', '{$last_name}', '{$other_names}', '{$gender}', '{$age}', '{$location}', '{$district}', '{$email_address}','{$phone_number}', '{$postal_address}', '{$username}', '{$password}')";
      if($db->query($sql)){
        $session->msg("s", "Registration Successful");
        redirect('registration.php',false);
      }

	  else {

        $session->msg("d", "Registration failed! Try again.");
        redirect('registration.php',false);
      }
   }
   else {
     $session->msg("d", $errors);
     redirect('registration.php',false);
   }
 }
?>
<?php include ('general_header.php'); ?>


 <div class="container">
		     <?php echo display_msg($msg); ?>
 
      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item active">Guest Registration </li>
			</ol>

		  <!--start create user category -->
 <div class="card mb-3">
        <div class="card-header"><i class = "fa fa-plus"></i> <i class = "fa fa-user"></i>  <span>Register </span></div>
        <div class="card-body">
          <form method = "post" action = "registration.php">
            <div class="form-group">
              <div class="form-row">
               
				<div class="col-md-4">
				First Name
                  <div class="form-group">
                    <input type="text"  class="form-control"  name = "first_name" required="required" >
                  </div>
                </div>
				<div class="col-md-4">
				Last Name
                  <div class="form-group">
                    <input type="text"  class="form-control" name = "last_name" required="required" >
                  </div>
                </div>
				<div class="col-md-4">
				Other Names
                  <div class="form-group">
                    <input type="text"  class="form-control" name = "other_names">
                  </div>
                </div>
				<div class = "col-md-4">
				    Gender
                <select class="form-control" name="gender">
				<option value = ""> --Select-- </option>
				<option value = "M">Male </option>
                   <option value="F">Female</option>  
                </select>
				</div>
				<div class="col-md-4">
				    Age
                  <div class="form-group">
                    <input type="number"  class="form-control" name = "age" required="required">
                  </div>
                </div>
				
				<div class="col-md-4">
				    Location
                  <div class="form-group">
                    <input type="text" class="form-control" name = "location" required="required">
                  </div>
                </div>
				
				<div class = "col-md-4">
				    District
                <select class="form-control" name="district" required = "required">
				<option value = "">--Select -- </option>
			   <?php 
			   $districts = find_all('districts');
			   foreach ($districts as $district): ?>
				<option value = "<?php echo $district['id']?>"><?php echo $district['name']; ?></option>
				<?php endforeach; ?>
                </select>
				</div>
				<div class="col-md-4">
				Email 
                  <div class="form-group">
                    <input type="email"  class="form-control" name = "email_address" required="required">
                  </div>
                </div>
				
				<div class="col-md-4">
				Phone
                  <div class="form-group">
                    <input type="phone"  class="form-control" name = "phone_number" required="required">
                  </div>
                </div>
				<div class="col-md-4">
				Postal Address
                  <div class="form-group">
                    <input type="address"  class="form-control" name = "postal_address" required="required">
                  </div>
                </div>
				<div class="col-md-4">
				Username
                  <div class="form-group">
                    <input type="text"  class="form-control" name = "username" required="required">
                  </div>
                </div>
				<div class="col-md-4">
				Password
                  <div class="form-group">
                    <input type="password"  class="form-control" name = "password" required="required">
                  </div>
                </div>
			
				
                <div class="col-md-4">
                  <div class="form-label-group">
                            <button  name="register" class="btn btn-primary pull-right"> Register</button>
                    </div>
                </div>
              </div>

            </div>

           
           
          </form>
         
        </div>
   
    </div>
	</div>
	</div>
	
	
		  
		  
		  <!-- end add user category -->
		  
		  

        </div>
        <!-- /.container-fluid -->

       

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
  
