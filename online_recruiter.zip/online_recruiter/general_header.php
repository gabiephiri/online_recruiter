<?php
include_once ('includes/load.php');
$total_active_jobs = count_active_jobs();

 $count_general_notifications = count_by_id('messages');
?>

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
	
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Recruiter</title>
	<link href="images/nb_icon.png" rel="shortcut icon" type = "img/png">


    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

		   <!-- <link href="vendor/bootstrap/css/style.css" rel="stylesheet"> -->


    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
	<link href = "css/main.css" rel = "stylesheet">
	 


  </head>


  <body id="page-top" style = "font-family:Arial, Halvetica, Bodoni MT, Sans-serif">

    <nav class="navbar navbar-expand navbar-dark static-top" style = "background:radial-gradient(circle, white, lightgreen, black, darkblue)">

      <a class="navbar-brand mr-1 pull-left" href="admin.php"><center><img src = "images/nb_icon.png" width = "18%" height="18%"></center></a>

      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <b>Online Recruiter</b>
      </button>
	  

      <!-- Navbar Search -->
     
	  <button class="btn btn-link btn-sm text-white order-1 order-sm-0 d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0" id="sidebarToggle1">
	  <a href="index.php" style = "text-decoration:none; color:white;"> <i class="fas fa-wrench"> &nbsp;Latest Jobs <sup style = "color:white;">  <span class="badge badge-danger" title = "New Jobs"data-toggle = "tooltip" data-placement="bottom"><?php echo $total_active_jobs; ?>+</span></i></a>  
      </button>
	  <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle2">
	   <a href="tnc.php" style = "text-decoration:none; color:white;"> <i class="fas fa-first-aid"> &nbsp; Info</i></a> 
     
      </button>
	  <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle3">
	   <a href="registration.php" style = "text-decoration:none; color:white;"> <i class="fas fa-user-plus"> &nbsp;Register</i></a> 
      </button>
	   <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle4" href="#">
	   <a href="accounts/" style = "text-decoration:none; color:white;"> <i class="fas fa-lock"> &nbsp;Candidate</i></a> 
      </button>
	  <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle4" href="#">
	   <a href="staff/" style = "text-decoration:none; color:white;"> <i class="fas fa-lock"> &nbsp;Employer</i></a> 
      </button>
	  

     

    </nav>

    <div id="wrapper">

	  
	  
	   <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="c_logout.php">Logout</a>
          </div>
        </div>
      </div>
    </div>
 <!-- Sticky Footer -->
 <footer style = "display:block; overflow:absolute;position: absolute; right: 0;bottom: 0; left:0; padding-top:2px; width:100%; height: 5%;background:linear-gradient(to right, green, black);color:white;
}">
<center>Copyright &copy; Recruiter <?php echo date ('Y'); ?></center>
</footer>
<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});
</script>
	
	
	
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

    <!-- Demo scripts for this page-->
    <script src="js/demo/datatables-demo.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>
