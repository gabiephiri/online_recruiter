<?php
	include "includes/load.php";
		$id = $_GET['eid'];	
		$user_info = find_by_id('users', $id);	
		$user_id = $user_info['id'];
		$all_departments = find_all('departments');
		$all_user_groups = find_all('user_groups');	
		
?>

<?php
//Update User basic info
  if(isset($_POST['update_user'])) {
    $req_fields = array('first_name','last_name','username','user_group', 'phone_number', 'email_address', 'department', 'user_group');
    validate_fields($req_fields);
    if(empty($errors)){
         $user_id = (int) $_POST['user_id'];
		    $title = remove_junk($db->escape($_POST['title']));
           $first_name = remove_junk($db->escape($_POST['first_name']));
		   $last_name = remove_junk($db->escape($_POST['last_name']));
		   $other_names = remove_junk($db->escape($_POST['other_names']));
           $username = remove_junk($db->escape($_POST['username']));
		   $email_address = remove_junk($db->escape($_POST['email_address']));
		   $department = remove_junk($db->escape($_POST['department']));
		  $phone_number = remove_junk($db->escape($_POST['phone_number']));
		   $status = remove_junk($db->escape($_POST['status']));
		   $user_group = remove_junk($db->escape($_POST['user_group']));
					  

         $sql = "UPDATE users SET title = '{$title}', first_name ='{$first_name}', last_name ='{$last_name}',other_names='{$other_names}',   email_address = '{$email_address}', phone_number = '{$phone_number}',  department = '{$department}',user_level = '{$user_group}',
			status='{$status}' WHERE id='{$user_id}'";
         $result = $db->query($sql);
          if($result && $db->affected_rows() === 1){
			  			insert_act('account', 'updated', '1');

            $session->msg('s',"Acount Updated ");
            redirect('manage_users.php', false);
          } else {
			insert_act('account', 'updated', '0');
            $session->msg('d',' Sorry failed to updated!');
            redirect('manage_users.php', false);
          }
    } else {
      $session->msg("d", $errors);
      redirect('manage_users.php',false);
    }
  }
?>

 <form method = "post" action = "edit_user.php">
	<table class="table table-striped">
	
		<tr>
		 <th>Title </th>
		 <td><select class="form-control" name="title">
				 <option <?php if($user_info['title'] === 'Mr') echo 'selected="selected"';?>value="Mr">Mr</option>
                  <option <?php if($user_info['title'] === 'Mrs') echo 'selected="selected"';?> value="Mrs">Mrs</option>
				  <option <?php if($user_info['title'] === 'Ms') echo 'selected="selected"';?> value="Ms">Ms</option>
				  <option <?php if($user_info['title'] === 'Dr') echo 'selected="selected"';?> value="Dr">Dr</option>
				   <option <?php if($user_info['title'] === 'Prof') echo 'selected="selected"';?> value="Prof">Prof</option>
                </select>
			</td>
		 </tr>
		
		<tr>
			<th>First Name</th>
		 <td> <input name = "first_name" type = "text" class = "form-control" value = "<?php echo $user_info['first_name'] ?>"></td>
		</tr>
		<tr>
	   <th>Last Name </th>
		 <td> <input name = "last_name" type = "text" class = "form-control" value = "<?php echo $user_info['last_name'] ?>"></td>
		 </tr>
		 
		 <tr>
		 <th>Other Names </th>
		 <td> <input name = "other_names" type = "text" class = "form-control" value = "<?php echo $user_info['other_names'] ?>"></td>
		 </tr>
		  <tr>
		 <th>Username </th>
		 <td> <input name = "username" type = "text" class = "form-control" value = "<?php echo $user_info['username'] ?>"></td>
		 </tr>
		  <th>Email Address </th>
		 <td> <input name = "email_address" type = "text" class = "form-control" value = "<?php echo $user_info['email_address'] ?>"></td>
		 </tr>
		  <th>Phone Number </th>
		 <td> <input name = "phone_number" type = "text" class = "form-control" value = "<?php echo $user_info['phone_number']; ?>"></td>
		 </tr>
		<tr>
			<th>Department</th>
		<td>
	       <select class="form-control" name="department">
                  <?php foreach ($all_departments as $department ):?>
                   <option <?php if($department['id'] === $user_info['department']) echo 'selected="selected"';?> value="<?php echo $department['id'];?>"><?php echo ucwords($department['name']);?></option>
                <?php endforeach;?>
                </select>

			</td>
		</tr>
		<tr>
			<th>User Group</th>
		 <td>   <select class="form-control" name="user_group">
                  <?php foreach ($all_user_groups as $group ):?>
                   <option <?php if($group['id'] === $user_info['user_level']) echo 'selected="selected"';?> value="<?php echo $group['id'];?>"><?php echo ucwords($group['group_name']);?></option>
                <?php endforeach;?>
                </select>
		</tr>
		
		<tr>
		<th>Status</th>
			<td><select class="form-control" name="status" required = "required">
                  
                  <option <?php if($user_info['status'] === '1') echo 'selected="selected"';?>value="1">Active</option>
                  <option <?php if($user_info['status'] === '0') echo 'selected="selected"';?> value="0">Inactive</option>
                
                </select></td>
		</tr>
		
		<tr>
	
			<td><button class = "btn btn-success" type = "submit" name = "update_user">Update</td>
	        <td><input name = "user_id" type = "number" class = "form-control" style = "visibility:hidden;"value = "<?php echo $user_info['id']; ?>"></td>
		</tr>
		<tr>
		
		
	
	</table>
	</form>	
	
	


<?php
// Update user password
if(isset($_POST['update_password'])) {
  $req_fields = array('password');
  validate_fields($req_fields);
  if(empty($errors)){
           $id = (int)$user_info['id'];
     $password = remove_junk($db->escape($_POST['password']));
     $h_pass   = sha1($password);
          $sql = "UPDATE users SET password='{$h_pass}' WHERE id='{$db->escape($id)}'";
       $result = $db->query($sql);
        if($result && $db->affected_rows() === 1){
			insert_act('password', 'changed', '1');
          $session->msg('s',"User password has been updated ");
          redirect('manage_users.php', false);
        } else {
		  insert_act('password', 'changed', '0');
          $session->msg('d',' Sorry failed to updated user password!');
          redirect('manage_users.php', false);
        }
  } else {
    $session->msg("d", $errors);
    redirect('manage_users.php',false);
  }
}
?>

