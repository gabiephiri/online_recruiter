<?php
	include "includes/load.php";
	$id = $_GET['eid'];
	$job_info = find_by_id('jobs', $id);
	$district_info = find_by_id ('districts', $job_info['district']);
	$districtName = $district_info ['name'];
	$count_days_to_expiry = count_days_to_expiry($id);
	
	
?>

<?php


?>
<head><link href = "vendor/bootstrap/css/bootstrap.css"></head>
	<table class="table table-striped">
		
		
		<tr>
			<th>Basic Info</th>
			<td>Job Title : <?php echo $job_info['title']; ?> <br /> Agents Needed <?php echo $job_info['agentCount'] ?> </td>
		</tr>
		
		<tr>
			<th>Location:</th>
			<td>Trading Center : <?php echo $job_info['location']; ?><br /> District :<?php echo $districtName; ?></td>
		</tr>
		<tr>
			<th>Dates</th>
			<td>Application Close Date : <?php echo read_date($job_info['deadline'])?> <br />Date Added: <?php echo read_date($job_info['dateAdded'])?> <br /> <?php echo $count_days_to_expiry; ?> days to close </td>
		</tr>
		<tr>
			
			<th>Job Description </th>
			<td><?php echo $job_info['jobDescription']; ?> </td>
		</tr>
		<tr>
		<th> Person Description  : </th> 
		<td><?php echo $job_info['personSpecification']; ?></td>
		</tr>
		
	</table>
<script src = "vendor/bootstrap/js/bootrap.js"></script>
