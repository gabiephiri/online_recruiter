<?php
  $page_title = 'Home Page';
  require_once('includes/load.php');
  if (!$session->isUserLoggedIn(true)) { redirect('index.php', false);}
?>
<?php include ('header.php'); ?>

      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Overview</li>
          </ol>
<div class="col-md-12">

    <?php echo display_msg($msg); ?>
  </div>
    <div class="panel">
      <div class="jumbotron col-md-12 text-center">
         <h1>This is the home page!</h1>
         <h2>browse around to access pages.</h2>
      </div>
    </div>
 </div>

          <!-- Icon Cards-->
          
        

          <!-- DataTables Example -->
          
        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Recruiter <?php echo date ('Y')?></span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
  
