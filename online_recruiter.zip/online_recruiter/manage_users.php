 
<?php include("includes/load.php");
$all_departments = find_all('departments');
$all_user_groups = find_all('user_groups');
$all_users = find_all_user();
$page_title = 'Manage Users';
 ?>
  <?php
 if(isset($_POST['submit_user'])){
   $req_field = array('first_name', 'last_name', 'username', 'email_address', 'phone_number', 'department', 'user_group');
   validate_fields($req_field);
   $first_name = remove_junk($db->escape($_POST['first_name']));
   $last_name = remove_junk($db->escape($_POST['last_name']));
   $other_names = remove_junk($db->escape($_POST['other_names']));
   $title = remove_junk($db->escape($_POST['title']));
   $username= remove_junk($db->escape($_POST['username']));
   $email_address = remove_junk($db->escape($_POST['email_address']));
   $phone_number = remove_junk($db->escape($_POST['phone_number']));
   $department = remove_junk($db->escape($_POST['department']));
   $user_group = remove_junk($db->escape($_POST['user_group']));
  
   
   //create default password as a hash of first letter of lastname and full firstname
   
   $lower_surname = strtolower($last_name);
    $password = sha1($lower_surname);
   //end password creation 
   
   if(empty($errors)){
      $sql  = "INSERT INTO users (title, first_name, last_name, other_names, username, email_address, password, phone_number, department, user_level)";
      $sql .= " VALUES ('{$title}','{$first_name}', '{$last_name}', '{$other_names}','{$username}', '{$email_address}', '{$password}','{$phone_number}', '{$department}', '{$user_group}')";
      if($db->query($sql)){
		  insert_act('user', 'added', '1');
        $session->msg("s", "Successfully added user");
        redirect('manage_users.php',false);
      } else {
		  		  insert_act('user', 'added', '0');

        $session->msg("d", "Sorry failed to create user.");
        redirect('manage_users.php',false);
      }
   } else {
     $session->msg("d", $errors);
     redirect('manage_users.php',false);
   }
 }
?>
    <?php
	include('header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header">
       <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Admin</a>
            </li>
            <li class="breadcrumb-item active">Manage Users</li>
			<li class="breadcrumb-item active">All Users</li>
			<li class="breadcrumb-item pull-right">
			
			 <a class = "breadcrumb-item newEmployee">Add User</a>

            </li>

          </ol>
		</div>
        <div class="row">
		<!-- start with table of users -->
		
		 <div class="col-md-7">
            <table class="table table-striped" id = "dataTable" cellspacing = "0">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Dept</th>
				   <th>Role</th>
                   <th>Actions</th>
				 
              </thead>
			    <tfoot>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Dept</th>
				  <th>Role</th>
                  <th> Actions</th>
				 
                </tr>
              </tfoot>
              <tbody>
			  <?php
	  
	  foreach ($all_users  as $a_user): 
	  ?>

		<tr class='prev' id="pre<?php echo $a_user['id']?>">
      <td><?php echo count_id() ?></td>
       <td><?php echo $a_user['first_name']. ' '. $a_user['last_name'];?> </td>
		<td><?php echo $a_user['email_address'] ?></td>
		<td><?php echo $a_user['dept_name']; ?></td>
        <td><?php echo $a_user['group_name'];?></td>
        
		<td>
		<div class='btn btn-info btn-xs view-button' did='<?php echo $a_user['id']?>'><i class = 'fa fa-info' title = "info & create new"data-toggle = "tooltip" data-placement="bottom"></i></div>
			 <div class='btn btn-warning edit-button btn-xs' xid ='<?php echo $a_user['id']?>'><i class = 'fa fa-edit'  title = "edit"data-toggle = "tooltip" data-placement="bottom"></i></div>

                 <button class = 'btn btn-danger'onclick = "deleteUser(<?php echo $a_user['id']?>)" class="btn btn-danger"  title="Delete" data-toggle="tooltip">
                  <span class="fa fa-trash"></span></button> 
     <a href='printprofile.php?employee=$employee' class='btn btn-info  btn-xs' target='_new'><i class = 'fa fa-print'  title = "print info"data-toggle = "tooltip" data-placement="bottom"></i></a></td>
         </tr>
	<?php endforeach; ?>

			  
		
			  
			  </tbody>		
         </table>

          </div>
		
		
		
		<!-- end table of  users --->
          <div class="col-md-5 employeeform" style = "display:none;">
            <p id="message"></p>
            <form method="post" id="insert">
             <table class="table table-striped">
		
		
		<tr>
             <th> <input type="text" name="first_name" class="form-control" placeholder="First  Name " required></th>
			<td><input type="text" name="last_name" class="form-control" placeholder="Last Name " required></td>
		</tr>
		
		<tr>
			<th><input type="text" name="other_names" class="form-control" placeholder="Other Names " required></th>
			<td>
			 <select class="form-control" name="title">
				<option value = "">Title </option>
                   <option value="Mr">Mr</option>
				    <option value="Mrs">Mrs</option>
					 <option value="Dr">Dr</option>
					 <option value="Prof">Professor</option>
              </select>
			</td>
		</tr>
		<tr>
			<th><input type="text" name="username" class="form-control" placeholder="User Name" required></th>
			<td><input type="phone" name="phone_number" class="form-control" placeholder="Phone Number " required></td>
		</tr>
		<tr>
			<th><input type="email" name="email_address" class="form-control" placeholder="Email " required></th>
			<td><select class="form-control" name="department" required = "required">
				<option value = "">Select User Department </option>
                  <?php foreach ($all_departments as $a_ud ):?>
                   <option value="<?php echo $a_ud['id'];?>"><?php echo ucwords($a_ud['name']);?></option>
                <?php endforeach;?>
                </select>
			</td>
		</tr>
		<tr>
			<th>
			
			 <select class="form-control" name="user_group" required = "required">
				<option value = "">Select User Group</option>
                  <?php foreach ($all_user_groups as $a_ug ):
				  ?>
                   <option value="<?php echo $a_ug['id'];?>"><?php echo ucwords($a_ug['group_name']);?></option>
                <?php endforeach;?>
                </select>
			
			</th>
		</tr>
		<tr>
			<th><button type="submit" name = "submit_user"class="btn btn-block btn-info insertButton">Submit</button></th>
			
		</tr>
		<tr>
		<th colspan = '2'><label> Default password is last name in small caps</th>
			
		</tr>
			
	</table>
            </form>
          </div>
          <div class="col-md-5 viewemployee" style="display:none;"></div>

         
		  </div>
		  
        </div>
      </div>
	  </div>
	  </div>

    </div><!-- /.container -->
 
          

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   <script> 
      $(document).ready(function(){
        /** Load Employee List not needed 
        $.ajax({
          url:"loademployee.php",
          dataType: "html",
          success: function(Result){
            $('#showEmployee').html(Result);
          }
        })
        var result = function(){ $.post('loademployee.php', {'request':'result'}).done(function(data){$('#showEmployee').html(data)}); }
        setInterval(result, 10000); **/

       /** Insert Employee not needed handled internally in this file 
       $('#insert').submit(function(event){
          event.preventDefault();
          $.ajax({
            url: "insert.php",
            method: "post",
            data: $('form').serialize(),
            dataType: "text",
            success: function(strMessage){
              $('#message').html(strMessage);
              $('#insert')[0].reset();
            }
          })
        }) **/

        //View Employee
        $(document).on('click', '.view-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("did"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "user_info.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		
		
		  //View Employee
        $(document).on('click', '.edit-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("xid"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "edit_user.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		

		 function deleteUser(x){
           sweetAlert({   title: "Proceed to delete user?!",
                                text: "user account will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_user.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } 
										  
					});
		
		 

		 }
		
		
		


        /**Delete Employee
        $(document).on('click', '.delete-button', function(){ 
          var eid = $(this).attr("did"); 
          var Data = {'eid':eid};
          $('#pre'+eid).hide(1000);
          $.ajax({
            url: "delemployee.php",
            method: "get",
            data: Data,
            // dataType: "text",
            success: function(response){
            }
          })
        });
		**/
		
	
	 $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
	 });


      });
    </script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	
	<script type="text/javascript">
function deleteUser(x){
sweetAlert({   title: "Proceed to delete user?!",
                                text: "user account will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_user.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } });
}
</script>
  </body>
  
</html>
