-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 05, 2019 at 10:11 PM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `recruiter`
--

-- --------------------------------------------------------

--
-- Table structure for table `acts_log`
--

DROP TABLE IF EXISTS `acts_log`;
CREATE TABLE IF NOT EXISTS `acts_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `status` enum('1','0') NOT NULL,
  `actor` int(11) NOT NULL,
  `dateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_actor_id` (`actor`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acts_log`
--

INSERT INTO `acts_log` (`id`, `object`, `action`, `status`, `actor`, `dateAdded`) VALUES
(1, 'job', 'added', '1', 1, '2018-10-30 13:23:27'),
(2, 'account', 'updated', '1', 1, '2018-11-06 01:16:34'),
(3, 'account', 'updated', '1', 1, '2018-11-06 01:16:45'),
(4, 'user', 'added', '1', 1, '2018-11-06 01:33:56'),
(5, 'user account', 'updated', '1', 1, '2018-11-06 01:34:30'),
(6, 'user', 'added', '1', 1, '2018-11-16 20:58:48'),
(7, 'job', 'updated', '1', 3, '2018-11-17 07:25:12'),
(8, 'job', 'updated', '1', 3, '2018-11-17 07:26:13'),
(9, 'job', 'updated', '1', 3, '2018-11-17 07:27:39'),
(10, 'job', 'deleted', '1', 3, '2018-11-17 07:40:30'),
(11, 'account', 'updated', '1', 3, '2018-11-17 17:27:30'),
(12, 'account', 'updated', '1', 3, '2018-11-17 17:28:19'),
(13, 'account', 'updated', '1', 3, '2018-11-17 17:28:31'),
(14, 'account', 'updated', '1', 3, '2018-11-17 17:28:38'),
(15, 'user', 'added', '1', 1, '2018-11-17 17:32:57'),
(16, 'screening question', 'added', '1', 3, '2018-11-21 07:31:18'),
(17, 'screening question', 'added', '1', 3, '2018-11-21 07:34:29'),
(18, 'screening question', 'added', '1', 3, '2018-11-21 07:38:09'),
(19, 'question', 'updated', '1', 3, '2018-11-21 08:33:12'),
(20, 'question', 'updated', '1', 3, '2018-11-21 08:33:22'),
(21, 'screening question', 'deleted', '1', 3, '2018-11-21 16:36:28'),
(22, 'screening question', 'added', '1', 3, '2018-11-21 16:37:53'),
(23, 'screening question', 'added', '1', 3, '2018-11-21 16:52:31'),
(24, 'screening question', 'added', '1', 3, '2018-11-21 16:57:09'),
(25, 'screening question', 'added', '1', 3, '2018-11-21 17:02:25'),
(26, 'question', 'updated', '1', 3, '2018-11-21 17:09:28'),
(27, 'screening question', 'added', '1', 3, '2018-11-21 17:14:10'),
(28, 'screening question', 'added', '1', 3, '2018-11-21 17:15:46'),
(29, 'screening question', 'deleted', '1', 3, '2018-11-21 17:16:19'),
(30, 'job', 'updated', '1', 3, '2018-11-23 04:29:11'),
(31, 'job', 'updated', '1', 3, '2018-11-23 04:29:56'),
(32, 'applicant', 'approved by cards to', '1', 3, '2018-11-25 05:53:04'),
(33, 'job', 'added', '1', 3, '2018-11-25 22:30:33'),
(34, 'screening question', 'added', '1', 4, '2018-11-25 22:36:14'),
(35, 'screening question', 'added', '1', 4, '2018-11-25 22:37:29'),
(36, 'screening question', 'added', '1', 4, '2018-11-25 22:38:45'),
(37, 'screening question', 'added', '1', 4, '2018-11-25 22:41:21'),
(38, 'screening question', 'added', '1', 4, '2018-11-25 22:42:44'),
(39, 'screening question', 'added', '1', 4, '2018-11-25 22:44:46'),
(40, 'screening question', 'added', '1', 4, '2018-11-25 23:21:42'),
(41, 'screening question', 'added', '1', 4, '2018-11-25 23:23:06'),
(42, 'screening question', 'added', '1', 4, '2018-11-25 23:27:56'),
(43, 'user account', 'updated', '0', 4, '2018-11-27 00:14:19'),
(44, 'user', 'added', '1', 1, '2018-11-27 01:35:52'),
(45, 'short message', 'sent', '1', 4, '2018-11-27 11:16:55'),
(46, 'short message', 'sent', '1', 4, '2018-11-27 11:47:09'),
(47, 'short message', 'sent', '1', 1, '2018-11-27 11:55:23'),
(48, 'applicant', 'approved by cards to', '1', 4, '2019-01-05 00:05:54'),
(49, 'screening question', 'added', '1', 3, '2019-01-05 17:41:37'),
(50, 'applicant', 'approved by cards to', '1', 3, '2019-01-05 20:30:29'),
(51, 'applicant', 'approved by cards to', '1', 4, '2019-01-05 20:32:20'),
(52, 'applicant', 'approved by cards to', '1', 4, '2019-01-05 20:54:13'),
(53, 'applicant', 'approved by cards to', '1', 4, '2019-01-05 21:21:37'),
(54, 'applicant', 'approved by cards to', '1', 4, '2019-01-05 21:24:49'),
(55, 'applicant', 'approved by cards to', '1', 4, '2019-01-05 21:27:37'),
(56, 'account', 'updated', '1', 4, '2019-01-05 21:39:08'),
(57, 'account', 'updated', '1', 4, '2019-01-05 21:39:30'),
(58, 'account', 'updated', '0', 4, '2019-01-05 21:39:42'),
(59, 'account', 'updated', '1', 4, '2019-01-05 21:48:06'),
(60, 'password', 'changed', '1', 4, '2019-01-05 21:48:21'),
(61, 'account', 'updated', '1', 3, '2019-01-05 21:52:11'),
(62, 'password', 'changed', '1', 3, '2019-01-05 21:52:20'),
(63, 'account', 'updated', '1', 1, '2019-01-05 21:56:54'),
(64, 'password', 'changed', '1', 1, '2019-01-05 21:57:05');

-- --------------------------------------------------------

--
-- Table structure for table `applies_for`
--

DROP TABLE IF EXISTS `applies_for`;
CREATE TABLE IF NOT EXISTS `applies_for` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jobId` int(11) NOT NULL,
  `candidateId` int(11) NOT NULL,
  `dateApplied` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cardsDecision` enum('0','1','2') NOT NULL DEFAULT '0',
  `cardsRejectReason` text,
  `cardsDecisionDate` timestamp NULL DEFAULT NULL,
  `candidateRank` int(11) DEFAULT NULL,
  `hrDecision` enum('0','1','2') NOT NULL DEFAULT '0',
  `hrDecisionDate` timestamp NULL DEFAULT NULL,
  `overallStatus` varchar(45) DEFAULT 'Not Started',
  PRIMARY KEY (`jobId`,`candidateId`),
  KEY `id` (`id`),
  KEY `fk_candidate_id` (`candidateId`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applies_for`
--

INSERT INTO `applies_for` (`id`, `jobId`, `candidateId`, `dateApplied`, `cardsDecision`, `cardsRejectReason`, `cardsDecisionDate`, `candidateRank`, `hrDecision`, `hrDecisionDate`, `overallStatus`) VALUES
(1, 8, 6, '2019-01-05 18:00:55', '0', NULL, NULL, NULL, '0', NULL, 'Not Started');

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

DROP TABLE IF EXISTS `candidates`;
CREATE TABLE IF NOT EXISTS `candidates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `other_names` varchar(55) DEFAULT NULL,
  `gender` enum('M','F') NOT NULL,
  `age` int(3) NOT NULL,
  `location` varchar(35) NOT NULL,
  `district` int(11) NOT NULL,
  `email_address` varchar(100) NOT NULL,
  `phone_number` varchar(45) DEFAULT NULL,
  `postal_address` text NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `cv` varchar(100) DEFAULT 'no_cv.pdf',
  `photo` varchar(100) DEFAULT 'no_photo.jpg',
  `certificate` varchar(255) NOT NULL DEFAULT 'no_cert.png',
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_businessDistrict` (`district`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`id`, `first_name`, `last_name`, `other_names`, `gender`, `age`, `location`, `district`, `email_address`, `phone_number`, `postal_address`, `username`, `password`, `cv`, `photo`, `certificate`, `date_added`, `last_login`) VALUES
(1, 'Junia', 'Kenz', 'Shamora', 'M', 24, 'Mkanda', 8, 'juniasham@ymail.com', '9030949304', 'C/O Ella Milanzie, P.O. Box 100, Mkanda, Mchinji', 'gabie', '68a5fd59bf95dca9adb0c4beb778c8e606265ec1', '88453-1972_ford_mustang-1920x1080.jpg', '63561-1972_ford_mustang-1920x1080.jpg', 'no_cert.png', '2018-11-07 19:05:40', NULL),
(2, 'Yona', 'Zulu', 'Langisha', 'M', 22, 'Chikanda', 27, 'yoz@pill.ac.mw', '998383737', 'C/O Ella Milanzie, P.O. Box 102, Chikanda, Zomba', 'data.com', '91ca03967892df0f1090c27f6c6cc987206114f8', '91635-screenshot-(5).png', '80846-screenshot-(12).png', 'no_cert.png', '2018-11-11 05:56:06', NULL),
(3, 'Timpunza', 'Mwale', 'Kapado', 'M', 45, 'Chirimba', 18, 'tim@quickmailer.mw', '0232124345', 'P.O. Box 120, Makata, Blantyre 3', 'carlsberg', 'd3b8b3f0cacad872f07fabc2811ca600b56179a6', '66208-85640-mechro-logo-icon.gif', '78338-screenshot-(9).png', 'no_cert.png', '2018-11-12 09:52:54', '2018-11-26 06:23:21'),
(5, 'Yohane', 'Mlunguzi', 'YOHMLU', 'M', 30, 'Likuni', 9, 'yomlunguzi@jin.com', '099828377', 'Box 10', 'Billy', '051522d0c46404d8ba5b692a10a37b99b8186360', '49521-win_20181122_21_54_19_pro.jpg', '36786-win_20181122_21_54_05_pro.jpg', 'no_cert.png', '2018-11-27 18:37:49', NULL),
(4, 'Denia', 'Tebulo', 'DENT', 'M', 27, 'Nkolokosa', 18, 'dent@nxv.co.mw', '0996736382', 'Box 50, Blantyre', 'debra', '78bacee28510780646091a4fc5aec50714d47fc2', '83145-12577-lighthouse.jpg', '12438-42219-screenshot-(15).png', 'no_cert.png', '2018-11-23 22:41:21', '2018-11-26 02:13:26'),
(6, 'Simoni', 'Kwakeni', 'SKEN', 'M', 22, 'Nyambadwe', 18, 'simk@internet.co.zm', '903893939743', 'P.O. Box 110, Blantyre 3', 'trialcandidate', '881416cc088de39362084a1bfe267aa86c162513', '2265-no_image.jpg', '73220-no_image.jpg', '63144-no_image.jpg', '2019-01-04 20:59:04', '2019-01-06 05:53:58');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
CREATE TABLE IF NOT EXISTS `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`) VALUES
(2, 'Cards & eBanking'),
(3, 'Wholesale Banking'),
(1, 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

DROP TABLE IF EXISTS `districts`;
CREATE TABLE IF NOT EXISTS `districts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `region` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_region` (`region`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `name`, `region`) VALUES
(1, 'Chitipa', 1),
(2, 'Karonga', 1),
(3, 'Rumphi', 1),
(4, 'Mzimba', 1),
(5, 'NkhataBay', 1),
(6, 'Nkhotakota', 2),
(7, 'Kasungu', 2),
(8, 'Mchinji', 2),
(9, 'Lilongwe', 2),
(10, 'Salima', 2),
(11, 'Dedza', 2),
(12, 'Dowa', 2),
(13, 'Mwanza', 3),
(14, 'Neno', 4),
(15, 'Mangochi', 4),
(16, 'Machinga', 4),
(17, 'Likoma Island', 1),
(18, 'Blantyre ', 3),
(19, 'Chiradzulu', 3),
(20, 'Chikwawa', 3),
(21, 'Thyolo', 3),
(22, 'Mulanje', 3),
(23, 'Nsanje', 3),
(24, 'Ntcheu', 2),
(25, 'Balaka ', 3),
(26, 'Phalombe', 3),
(27, 'Zomba', 4),
(28, 'Ntchisi', 2);

-- --------------------------------------------------------

--
-- Table structure for table `employed_candidates`
--

DROP TABLE IF EXISTS `employed_candidates`;
CREATE TABLE IF NOT EXISTS `employed_candidates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jobId` int(11) NOT NULL,
  `candidateId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_emp_cand` (`candidateId`),
  KEY `fk_emp_job` (`jobId`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employed_candidates`
--

INSERT INTO `employed_candidates` (`id`, `jobId`, `candidateId`) VALUES
(1, 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agentCount` int(11) NOT NULL DEFAULT '1',
  `title` varchar(200) NOT NULL,
  `location` varchar(30) NOT NULL,
  `district` int(11) NOT NULL,
  `jobDescription` text NOT NULL,
  `personSpecification` text NOT NULL,
  `dateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deadline` timestamp NOT NULL,
  `status` varchar(25) DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `fk_district` (`district`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `agentCount`, `title`, `location`, `district`, `jobDescription`, `personSpecification`, `dateAdded`, `deadline`, `status`) VALUES
(1, 9, 'Mkando Agent', 'Mkando TCZ1', 1, 'three workers with at least MSCE', 'highest customer care standards', '2018-10-04 23:49:35', '2018-11-30 08:00:00', NULL),
(2, 1, 'Lunzu Agent', 'Lunzu markets', 1, 'Dedicated', 'The bestest', '2018-10-04 23:52:49', '2018-11-25 02:00:00', NULL),
(3, 2, 'Chamveka Deposits Agent', 'SubT/A Sankhani', 1, 'Passion needed', 'Be able to speak Chinyanja and Chisenga', '2018-10-05 05:15:55', '2018-10-27 01:00:00', NULL),
(4, 3, 'Mgona mobile agent', 'Mgona Area 25', 1, 'be a recruiter', 'Be able to move from one place to the other', '2018-10-05 05:47:40', '2018-12-21 08:00:00', NULL),
(8, 7, 'Makata Agent', 'Makata', 18, 'To act as an agent in the area indicated ', 'be able to buy materials on your own', '2018-11-25 22:30:33', '2019-01-29 08:00:00', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(30) NOT NULL,
  `receivers` text NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `dateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `sender`, `receivers`, `subject`, `message`, `dateAdded`) VALUES
(1, 'hr@nbm.co.mw', 'chamvekaagent@gmail,com, 0993025347, lunzuwholesalers@yahoo.com', 'Congrats and interview schedule', 'You impressed NBM and have a great chance of becoming our agent. Come for a short interview with original business documents on 28 October from 08:30 AM', '2018-10-05 05:23:26');

-- --------------------------------------------------------

--
-- Table structure for table `message_recepient`
--

DROP TABLE IF EXISTS `message_recepient`;
CREATE TABLE IF NOT EXISTS `message_recepient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` int(11) NOT NULL,
  `recepientType` enum('C','A') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `message_sender`
--

DROP TABLE IF EXISTS `message_sender`;
CREATE TABLE IF NOT EXISTS `message_sender` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `senderType` enum('C','A') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

DROP TABLE IF EXISTS `regions`;
CREATE TABLE IF NOT EXISTS `regions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` enum('northern','central','southern','eastern') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`id`, `name`) VALUES
(1, 'northern'),
(2, 'central'),
(3, 'southern'),
(4, 'eastern');

-- --------------------------------------------------------

--
-- Table structure for table `screening_answers`
--

DROP TABLE IF EXISTS `screening_answers`;
CREATE TABLE IF NOT EXISTS `screening_answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jobId` int(11) NOT NULL,
  `questionNumber` int(11) NOT NULL,
  `answer` enum('A','B','C','D','N') NOT NULL DEFAULT 'N',
  `candidateId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_answer_job` (`jobId`),
  KEY `fk_answer_question` (`questionNumber`),
  KEY `fk_answer_candidate` (`candidateId`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `screening_answers`
--

INSERT INTO `screening_answers` (`id`, `jobId`, `questionNumber`, `answer`, `candidateId`) VALUES
(1, 8, 1, 'B', 6),
(2, 8, 1, 'B', 6),
(3, 8, 1, 'B', 6),
(4, 8, 1, 'B', 6),
(5, 8, 1, 'B', 6),
(6, 8, 1, 'B', 6),
(7, 8, 1, 'B', 6),
(8, 8, 1, 'B', 6);

-- --------------------------------------------------------

--
-- Table structure for table `screening_questions`
--

DROP TABLE IF EXISTS `screening_questions`;
CREATE TABLE IF NOT EXISTS `screening_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jobId` int(11) NOT NULL,
  `question` text NOT NULL,
  `a` varchar(125) NOT NULL,
  `b` varchar(125) NOT NULL,
  `c` varchar(125) NOT NULL,
  `d` varchar(125) NOT NULL,
  `answer` enum('A','B','C','D','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id`),
  KEY `fk_screen_job` (`jobId`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `screening_questions`
--

INSERT INTO `screening_questions` (`id`, `jobId`, `question`, `a`, `b`, `c`, `d`, `answer`) VALUES
(1, 8, 'What is the capital city of Malawi?', 'Mzimba', 'Lilongwe', 'Blantyre', 'Zomba', 'B');

-- --------------------------------------------------------

--
-- Table structure for table `short_messages`
--

DROP TABLE IF EXISTS `short_messages`;
CREATE TABLE IF NOT EXISTS `short_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `recepient` int(11) NOT NULL,
  `sender` int(11) NOT NULL,
  `dateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `short_messages`
--

INSERT INTO `short_messages` (`id`, `subject`, `message`, `recepient`, `sender`, `dateAdded`) VALUES
(3, 'Process terminated prematurely', 'Someone volunteered to work  totally for free... So we do not need to recruit for Zomba Thava', 4, 1, '2018-11-27 11:55:23'),
(2, 'Check candidate records', 'Would you verify the account records for Matakale Inv ASAP', 5, 4, '2018-11-27 11:47:09');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(10) NOT NULL,
  `first_name` varchar(60) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `other_names` varchar(45) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email_address` varchar(45) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_level` int(11) NOT NULL,
  `image` varchar(255) DEFAULT 'no_image.jpg',
  `status` int(1) NOT NULL DEFAULT '1',
  `last_login` datetime DEFAULT NULL,
  `department` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_user_level` (`user_level`),
  KEY `FK_department` (`department`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `title`, `first_name`, `last_name`, `other_names`, `username`, `email_address`, `phone_number`, `password`, `user_level`, `image`, `status`, `last_login`, `department`) VALUES
(1, 'Mrs', 'Trial', 'Admin', 'TADMIN', 'trialadmin', 'trialadmin@gmail.com', '202020102', 'd945929386963ce74a987a2d2ba43797a276777a', 1, 'no_image.jpg', 1, '2019-01-05 21:56:14', 1),
(3, 'Mr', 'Trial', 'HR', 'THR', 'trialhr', 'trialhr@gmail.com', '+2650939302839', 'efc00188577b768ee22e90c875668db379e2441a', 2, 'no_image.jpg', 1, '2019-01-05 21:52:36', 1),
(4, 'Mr', 'Trial', 'Interviewer', 'tinterviewer', 'trialinterviewer', 'trialinterviewer@mail.com', '09939398938', 'bace83b7ee182027355ebbddedc04943e6c09fef', 3, 'no_image.jpg', 1, '2019-01-05 21:51:07', 3),
(5, 'Mr', 'James', 'Ben', 'Kilode', 'ben', 'jamesben@gmail.com', '0939392029', '73675debcd8a436be48ec22211dcf44fe0df0a64', 3, 'no_image.jpg', 1, NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
CREATE TABLE IF NOT EXISTS `user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(150) NOT NULL,
  `group_level` int(11) NOT NULL,
  `group_status` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_level` (`group_level`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`id`, `group_name`, `group_level`, `group_status`) VALUES
(1, 'Admin', 1, 1),
(2, 'HR', 2, 1),
(3, 'Recruitment Unit', 3, 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
