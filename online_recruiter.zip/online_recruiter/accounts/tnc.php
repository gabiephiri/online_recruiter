 
<?php include("includes/load.php");
$latest_jobs = find_all_jobs();

 ?>
    <?php
	include('header.php');?> 
	<body  style = "background:url('images/bg_body.jpg');">
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header"  style = "background:color:#FFBB00; color:red">
       <ol class="breadcrumb" style = "background-color:lightgreen !important;">
	   <li class="breadcrumb-item active" ><marquee><b>
	   
	   <?php foreach ($latest_jobs as $a_job):
	   if(is_job_active($a_job['id'])):
	   
	   $jobState = $a_job['agentCount']. ' '. $a_job['title']. 's required at '. $a_job['location'].' in '.$a_job['district'].'... Job posted on : '. read_date($a_job['dateAdded']). '  Apply by '.read_date($a_job['deadline']);
	   
	   $jobState .= " <|> ";
	
	   ?>
	   
        <?php echo $jobState ?>
		<?php endif; ?>
			<?php endforeach; ?>
			<b></marquee></li>
			
          </ul>
		</div>
		
<div class="row">
  <div class="col-md-6">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="fa fa-arrow-right"></span>
          <span> Company Profile </span>
       </strong>
      </div>
     <div class="panel-body">
<strong> Mission</strong>
	<ul style ="list-style:square">

<li></li>
 

	 
	 </li>
   </ul>  
     </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="fa fa-arrow-up"></span>
          <span>Recruitment-related information <span>
       </strong>  
      </div>
     <div class="panel-body">
	  <ul style = "list-style:square">
	   <li>User stories</li>
       <li>Comments  feedback</li>
        <li>Partners</li> 

	   </li>
	   <ul>
     
     </div>
    </div>
  </div>
</div>
		
		
        </div>
      </div>
	 <!-- /.container -->
 
          

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
     <script> 
      $(document).ready(function(){


        //View Employee
        $(document).on('click', '.view-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("did"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "bursar_patient_info.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
        
		 
		
		

		
	
	 $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
	 });


      });
    </script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	
  </body>
  
</html>
