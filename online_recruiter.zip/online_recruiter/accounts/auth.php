<?php include_once('includes/load.php'); ?>
<?php
$req_fields = array('username','password' );
validate_fields($req_fields);
$username = remove_junk($_POST['username']);
$password = remove_junk($_POST['password']);

if(empty($errors)){
  $candidate_id = authenticate($username, $password);
  if($candidate_id){
    //create session with id
     $session->login($candidate_id);
    //Update Sign in time
     updateLastLogIn($candidate_id);
     $session->msg("s", "  Welcome to the Candidates Page.");
     redirect('jobs.php',false);

  } else {
    $session->msg("d", "Sorry Username/Password incorrect.");
    redirect('index.php',false);
  }

} else {
   $session->msg("d", $errors);
   redirect('index.php',false);
}

?>
