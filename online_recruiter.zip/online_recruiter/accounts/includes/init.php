<?php ob_start();
session_start();

include("dbconfig.php");
include("functions.php");
?>