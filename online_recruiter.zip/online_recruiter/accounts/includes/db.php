<?php

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'nbmore';

$db = mysqli_connect($host, $username, $password, $database) or die ('No database connection');
?>