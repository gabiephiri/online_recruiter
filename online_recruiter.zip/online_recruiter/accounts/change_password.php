<?php
	include "includes/load.php";
		$id = $_GET['eid'];	
		$user_info = find_by_id('candidates', $id);	
		$user_id = $user_info['id'];
		$all_departments = find_all('departments');
		$all_user_groups = find_all('user_groups');	
		
		$page_title = "Edit My Profile";
		
?>
<?php
// Update user password
if(isset($_POST['update_password'])) {
  $req_fields = array('password');
  validate_fields($req_fields);
  if(empty($errors)){
  $user_info = current_user();
           $id = (int)$user_info['id'];
     $password = remove_junk($db->escape($_POST['password']));
	      $candidate_id = $_POST['user_id'];

     $h_pass   = sha1($password);
          $sql = "UPDATE candidates SET password='{$h_pass}' WHERE id='{$db->escape($id)}'";
       $result = $db->query($sql);
        if($result && $db->affected_rows() === 1){
		
                echo "<script> alert ('Password Changed Successfully');</script>";  
        redirect('edit_profile.php?eid='.$candidate_id, false);
        } 
		else {
		echo "<script> alert ('sorry failed to update password');</script>";

          		redirect('edit_profile.php?eid='.$candidate_id, false);
        }
  } else {
    $session->msg("d", $errors);
    redirect('change_password.php?eid='.$candidate_id,false);
  }
}
?>
<?php include ('header.php'); ?>

<div class = "col-md-12">
<form method = "post" action = "change_password.php?eid="<?php echo $user_info['id']; ?>>
<h3 style = "background-color:gray">Password Change for <span style = "color:yellow"> <?php echo $user_info['name']; ?> </span></h3>
	<div class = "col-md-12">
	
		
		

		<div class = "col-md-10"> 
		 
			<span class = "label label-disabled pull-left">New Password </span>
			<span class = "input input-success pull-right">
		<input name = "password" type = "password" class = "form-control"> <span>
		</div>	
		<div class = "col-md-10">&nbsp;</div>
	<div class = "col-md-8">
	
		<button class = "btn btn-danger" type = "submit" name = "change_password">Change Password</button>
		 	<input class = "btn btn-disabled" value = "<?php echo $user_info['id']; ?>"type = "number" name = "user_id">
</div>
		 
		
	
</form>
</div>
</div>