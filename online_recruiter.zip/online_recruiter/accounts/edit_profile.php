<?php 
require_once ('includes/load.php');
$page_title = 'Edit Personal Information';
 $all_districts = find_all('districts');
 $id = $_GET['eid'];
 $candidate_info = find_by_id('candidates', $id);
 
 if (!$candidate_info)
 {
	 $session->msg('d', "Your identity could not be established");
	 redirect ('jobs.php', false);
 }
 
 ?>
 <?php
  
  if (isset($_POST['submit_changed_profile']))
  {

   $candidate_id = (int) remove_junk($db->escape($_POST['candidate_id']));   
	  
   $first_name = remove_junk($db->escape($_POST['first_name']));
   $other_names = remove_junk($db->escape($_POST['other_names']));
   $last_name = remove_junk($db->escape($_POST['last_name']));
   $username = remove_junk($db->escape($_POST['username']));
   $email_address = remove_junk($db->escape($_POST['email_address']));
   $phone_number = remove_junk($db->escape($_POST['phone_number']));
   $postal_address = remove_junk($db->escape($_POST['postal_address']));
   $location = remove_junk($db->escape($_POST['location']));
   $district = remove_junk($db->escape($_POST['district']));
   $age = remove_junk($db->escape($_POST['age'])); 
   $gender = remove_junk($db->escape($_POST['gender']));   
  
   
   //handling uploads
	
	//firstly file names
    
  
	  $updateCandidateQuery = "UPDATE  candidates  SET 
	                            first_name = '{$first_name}', last_name = '{$last_name}', other_names = '{$other_names}',username = '{$username}',
								email_address = '{$email_address}',  phone_number = '{$phone_number}',
	                           postal_address = '{$postal_address}',district = '{$district}', 
							   location = '{$location}', age = '{$age}', gender = '{$gender}'
								 WHERE id = '{$candidate_id}' LIMIT 1";
								

							   
		 if($db->query($updateCandidateQuery)){
		 $session->msg("s", "profile successfully updated");
        redirect("edit_profile.php?eid=".$candidate_id,false);
      } 
	  else {

        $session->msg("d", "Sorry failed to update profile... ");
        redirect("edit_profile.php?eid=".$candidate_id,false);
      }
							   
}							   
							   
	
  
  
  
  
  
 

  
?>
<?php include ('header.php'); ?>
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


 <div class="container">
		     <?php echo display_msg($msg); ?>
 
      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Candidate</a>
            </li>
            <li class="breadcrumb-item active">Manage Profile</li>
			<li class="breadcrumb-item pull-right">
             Edit Profile Information
            </li>
			<li class="breadcrumb-item pull-right">
             <a href="#changePass">Change Password</a>
            </li>
			</ol>

		  <!--start create user category -->
 <div class="card mb-3"  id = "add_uc">
        <div class="card-header"><i class = "fa fa-edit"></i> <i class = "fa fa-user"></i>  <span>Edit Your Info  <strong><?php echo $candidate_info['first_name']. ' '.$candidate_info['last_name']?> </strong> </span></div>
        <div class="card-body">
          <form method = "post" action = "edit_profile.php?eid=<?php echo $candidate_info['id']; ?>" enctype = "multipart/form-data">
            <div class="form-group">
            <div class="form-row">
			  
			</div>
				 <div class = "form-row">
			  
               
				<div class="col-md-3">
				First Name
                  <div class="form-group">
                    <input type="text"  class="form-control" value = "<?php echo $candidate_info['first_name'] ?>" name = "first_name" required="required"  autocomplete>
                  </div>
				  </div>
				  <div class="col-md-3">
				  Last Name
                  <div class="form-group">
                    <input type="text"  class="form-control" value = "<?php echo $candidate_info['last_name'] ?>" name = "last_name" required="required"  autocomplete>
                  </div>
				  </div>
				  
				  <div class="col-md-3">
				  Other Names
                  <div class="form-group">
                    <input type="text"  class="form-control" value = "<?php echo $candidate_info['other_names'] ?>" name = "other_names" required="required"  autocomplete>
                  </div>
				  </div>
				  
				  <div class="col-md-3">
				  Gender
                  <div class="form-group">
				  

			     <select class="form-control" name="gender" required = "required">
				 
                   <option <?php if($candidate_info['gender'] === "M") echo 'selected="selected"';?> value="M">Male</option>
				                      <option <?php if($candidate_info['gender'] === "F") echo 'selected="selected"';?> value="F">Female</option>

                </select>
			                  </div>
                </div>
				 <div class="col-md-3">
				 Age
                  <div class="form-group">
                    <input type="text"  class="form-control" value = "<?php echo $candidate_info['age'] ?>" name = "age" required="required"  autocomplete>
                  </div>
				  </div>
				  
				  <div class="col-md-3">
				  Location
                  <div class="form-group">
                    <input type="text"  class="form-control" placeholder="Location" value = "<?php echo $candidate_info['location']?>"name = "location" required="required" autocomplete >
                  </div>
                </div>
				
					<div class="col-md-3">
					District
                  <div class="form-group">
				  

			     <select class="form-control" name="district" required = "required">
				<option value = "">Select District</option>
                  <?php foreach ($all_districts as $a_district ):
				  ?>
                   <option <?php if($a_district['id'] === $candidate_info['district']) echo 'selected="selected"';?> value="<?php echo $a_district['id'];?>"><?php echo ucwords($a_district['name']);?></option>
                <?php endforeach;?>
                </select>
			    </div>
                </div>
				<div class="col-md-3">
				Username
                  <div class="form-group">
                    <input type="text"  class="form-control" value = "<?php echo $candidate_info['username'] ?>" name = "username" required="required"  autocomplete>
                  </div>
                </div>
				
				  </div>
				  
				<div class = "form-row"> 
				<div class="col-md-3">
				Email
                  <div class="form-group">
                    <input type="text"  class="form-control" value = "<?php echo $candidate_info['email_address'] ?>" name = "email_address" required="required"  autocomplete>
                  </div>
                </div>
              <div class="col-md-3">
			  Phone
                  <div class="form-group">
                    <input type="text"  class="form-control" value = "<?php echo $candidate_info['phone_number'] ?>" name = "phone_number" required="required"  autocomplete>
                  </div>
				  </div>
				  <div class="col-md-6">
				Postal Address
                  <div class="form-group">
                    <input type="text"  class="form-control" value = "<?php echo $candidate_info['postal_address']?>"name = "postal_address" required="required" autocomplete >
                  </div>
				
				</div>
				  </div>
				  <div class = "form-row">
				
				
				
				
                </div>
               			
				
				</div>
				<div class = "form-row">
				
               			
				
				</div>
			
				<div class = "form-row">	
                <div class="col-md-3">
                  <div class="form-group">
                            <button  name="submit_changed_profile" class="btn btn-primary pull-left"> Submit Changed Profile</button>


                    </div>
                </div>
				
				<div class="col-md-4">
                  <div class="form-group">
								<a href="edit_uploads.php?eid=<?php echo $candidate_info['id'];?>" class="btn btn-success pull-right"><i class = "fa fa-upload"></i>&nbsp; Update Uploaded Files</a>


                    </div>
                </div>
				

				</div>
				<div class="col-md-3" style = "display:none;">
                  <div class="form-group">
                    <input type="number"  class="form-control"  value = "<?php echo $candidate_info['id']?>" name = "candidate_id" required="required">
                  </div>
                </div>
				 </form>
<form method = "post" action = "edit_profile.php?eid=<?php echo $candidate_info['id']; ?>">

		
		
		
		<div class = "form-row" style = "background-color:light-green !important" id = "changePass">
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "permitImage"> Change Password</label>
                  </div>
                </div>
               
				<div class = "col-md-3">
				<div class = "form-group">
				 <input type = "password" class="form-control input-primary" name = "password"  type = "text" > 
				</div>
				
				</div>
				
				<div class = "col-md-3">
				<div class = "form-group">
				 <button class = "btn btn-danger" type = "submit" name = "update_password">Change </button> 
				</div>
				
				</div>	
                 <div class="col-md-3" style = "display:none;">
                  <div class="form-group">
                    <input type="number"  class="form-control btn-primary"  value = "<?php echo $candidate_info['id']?>" name = "candidate_id" required="required">
                  </div>
                </div>				
		</div>	
		</form>
		
		
              </div>
			       
         
            </div>

           
      
		  
	 
         
        </div>
   
    </div>
	</div>
	</div>
    </div>
   </div>
    </div>
<?php
// Update user password
if(isset($_POST['update_password'])) {
  	      $candidate_id = $_POST['candidate_id'];

      $password = remove_junk($db->escape($_POST['password']));

		 $h_pass   = sha1($password);
			  $sql = "UPDATE candidates SET password='{$h_pass}' WHERE id='{$db->escape($candidate_id)}'";
		   $result = $db->query($sql);
			if($result){
             echo "<script>alert('password changed successfully'); </script>";
			redirect('edit_profile.php?eid='.$candidate_id, false);
			} 
			else {
			 echo "<script>alert('sorry, failed to change password'); </script>";

			 redirect('edit_profile.php?eid='.$candidate_id, false);
			}
	  }  

?>