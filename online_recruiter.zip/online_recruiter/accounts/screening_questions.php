<?php require_once('includes/load.php');
$page_title = 'Screening Questions';
 
 $id = $_GET['id'];
 $job_info = find_by_id('jobs', $id);
 $all_questions = find_questions_by_job_id($job_info['id']);
 ?>
<?php include ('header.php'); ?>

      <div id="content-wrapper">
 		     <?php echo display_msg($msg); ?>

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Recruiter</a>
            </li>
            
			            <li class="breadcrumb-item active"> Screening Questions</li>

            
			
          </ol>



        

          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-users"></i>
              Questions for <strong><?php echo $job_info['title'];?></strong> Job</div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-striped" id="dataTable" width="100%" cellspacing="0">


                  <tbody>
		<?php 	
		$getQuestions =  "SELECT * FROM screening_questions WHERE jobId = '{$job_info['id']}'";
		$executeGet = $db->query ($getQuestions);
		
		 while ($a_question = mysqli_fetch_assoc($executeGet)):

		
		?>
          <tr>
           <td class="text-left"><b><?php echo count_id();?></b> . <?php echo ucfirst($a_question['question'])?> <br />
           A : <?php echo remove_junk(ucwords($a_question['a']))?><br />
		   B : <?php echo remove_junk(ucwords($a_question['b']))?><br />
           C : <?php echo remove_junk(ucwords($a_question['c']))?><br />
           D : <?php echo remove_junk(ucwords($a_question['d']))?><br/><br/>
		   Answer : <?php echo remove_junk(ucwords($a_question['answer']))?> <br /> <br />
		   
           
			 
                <a href="edit_question.php?id=<?php echo (int)$a_question['id'];?>" class="btn btn-xs btn-warning" data-toggle="tooltip" title="Edit">
                  <i class="fa fa-edit"></i>
               </a>
                <a onclick ="deleteQuestion(<?php echo$a_question['id']?>)" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Remove">
                  <i class="fa fa-trash"></i>
                </a>
               
           </td>
          </tr>
		  
        <?php endwhile;?>
		<tr>
			               <th><button class="btn btn-primary" name = "apply">Apply</button></th>

		
		</tr>
       </tbody>

	 <script>  
	   $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});
</script>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

       

      </div>
      <!-- /.content-wrapper -->

    </div>
	
<script type="text/javascript">
function deleteQuestion(x){
sweetAlert({   title: "Proceed to delete question?!",
                                text: "question will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_question.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } });
}
</script>
	
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
  
