<?php 
require_once ('includes/load.php');
$page_title = "Edit Business Information";
 $id = $_GET['eid'];
 $candidate_info = find_by_id('candidates', $id);
 
 if (!$candidate_info)
 {
	 $session->msg('d', "Your identity could not be established");
	 redirect ('jobs.php', false);
 }
 
 ?>
 
 <?php
 
    
    $passportPhotosFolder="candidate_uploads/passport_photos/"; //passport photos and ID images for directors, managers and assistants
	$certificatesFolder="candidate_uploads/certificates/"; //cvs business permits, and certificates for directors, managers and assistants
 //change CV
 
 
 
 if (isset($_POST['change_cv']))
 {
   $candidate_id = $_POST['candidate_id'];
     $cv = rand(1000, 100000)."-".$_FILES ['cv']['name'];
	 $cvTempFile = $_FILES['cv']['tmp_name'];
	 $lowercaseCV= strtolower($cv);
	 $finalCV = str_replace(' ','-',$lowercaseCV);
	 
	 	if (move_uploaded_file($cvTempFile, $certificatesFolder.$finalCV))
		{
		   
             $updateCV = "UPDATE candidates SET cv = '{$finalCV}' WHERE id = '{$candidate_id}' LIMIT 1";		   
					
		if($db->query($updateCV))
		{
        $session->msg("s", "successfully updated the CV");
        redirect('edit_uploads.php?eid='.$candidate_id,false);
      } 
	  else {

        $session->msg("d", "Sorry failed to the CV");
        redirect('edit_uploads.php?eid='.$candidate_id,false);
      }
		   
		}  
 }

 if (isset($_POST['change_certificate']))
 {
   $candidate_id = $_POST['candidate_id'];
     $certificate = rand(1000, 100000)."-".$_FILES ['certificate']['name'];
	 $certificateTempFile = $_FILES['certificate']['tmp_name'];
	 $lowercaseCertificate= strtolower($certificate);
	 $finalCertificate = str_replace(' ','-',$lowercaseCertificate);
	 
	 	if (move_uploaded_file($certificateTempFile, $certificatesFolder.$finalCertificate))
		{
		   
             $updateCertificate = "UPDATE candidates SET certificate= '{$finalCertificate}' WHERE id = '{$candidate_id}' LIMIT 1";		   
					
		if($db->query($updateCertificate))
		{
        $session->msg("s", "successfully updated the  highest certificate of Qualification");
        redirect('edit_uploads.php?eid='.$candidate_id,false);
      } 
	  else {

        $session->msg("d", "Sorry failed to the highest certificate of Qualification");
        redirect('edit_uploads.php?eid='.$candidate_id,false);
      }
		   
		}  
 }
 
 
 //start  passport photo change 
 
 if (isset($_POST['change_photo']))
 {
   $candidate_id = $_POST['candidate_id'];
     $photo= rand(1000, 100000)."-".$_FILES ['photo']['name'];
	 $photoTempFile = $_FILES['photo']['tmp_name'];
	 $lowercasePhoto= strtolower($photo);
	 $finalPhoto= str_replace(' ','-',$lowercasePhoto);
	 
	 	if (move_uploaded_file($photoTempFile, $passportPhotosFolder.$finalPhoto))
		{
		   
             $updatePhoto = "UPDATE candidates SET photo = '{$finalPhoto}' WHERE id = '{$candidate_id}' LIMIT 1";		   
					
		if($db->query($updatePhoto))
		{
        $session->msg("s", "successfully updated photo");
        redirect('edit_uploads.php?eid='.$candidate_id,false);
      } 
	  else {

        $session->msg("d", "Sorry failed change photo");
        redirect('edit_uploads.php?eid='.$candidate_id,false);
      }
		   
		}  
 }
  
 	 
 
  
 
 ?>
<?php include ('header.php'); ?>
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


 <div class="container">
		     <?php echo display_msg($msg); ?>
 
      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Candidate</a>
            </li>
            <li class="breadcrumb-item active">Manage Profile</li>
			<li class="breadcrumb-item pull-right">
             Edit Profile Information
            </li>
			</ol>

     <div class="card mb-3"  id = "add_uc">
        <div class="card-header"><i class = "fa fa-edit"></i> <i class = "fa fa-users"></i>  <span>Edit Your Info <strong><?php echo $candidate_info['first_name'].' '.$candidate_info['other_names'].' '.$candidate_info['last_name']?> </strong> </span></div>
        <div class="card-body">
            <div class="form-group">
            <div class="form-row">
			  <div class = "col-md-12">
                 </div>
		</div>
			
			
		
		<!-- update  CV  start-->
		<form method = "post" action = "edit_uploads.php?eid=<?php echo $candidate_info['id']; ?>" enctype = "multipart/form-data">		
		<div class = "form-row">
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "permitImage">CV</label>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
				  <img src = "candidate_uploads/certificates/<?php echo $candidate_info['cv']?>"  width = "100px" height = "100px" alt = "CV" style = "border-radius:50%"></img><br /><br />
					</div>
					 
                </div>
				
				<div class = "col-md-3">
				<div class = "form-group">
				 <input class="form-control btn-primary" name = "cv"  type = "file" value = "<?php echo $candidate_info['cv'] ?>"> 
				
				</div>
				
				</div>
				
				<div class = "col-md-3">
				<div class = "form-group">
				 <button class = "btn btn-success" name = "change_cv">Change </button> 
				</div>
				
				</div>
				 <div class="col-md-3" style = "display:none;">
                  <div class="form-group">
                    <input type="number"  class="form-control btn-primary"  value = "<?php echo $candidate_info['id']?>" name = "candidate_id" required="required">
                  </div>
                </div>
						
		</div>	
		</form>
		<!-- end CV update -->
		
		<!-- start update certificate -->
				<form method = "post" action = "edit_uploads.php?eid=<?php echo $candidate_info['id']; ?>" enctype = "multipart/form-data">

		<div class = "form-row">
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "permitImage">Certificate</label>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
				  <img src = "candidate_uploads/certificates/<?php echo $candidate_info['certificate']?>" alt = "certificate" width = "100px" height = "100px" style = "border-radius:40%"></img><br /><br />
					</div>
                </div>
				
				<div class = "col-md-3">
				<div class = "form-group">
				 <input class="form-control btn-primary" name = "certificate"  type = "file" value = "<?php echo $candidate_info['certificate'] ?>"> 
				</div>
				
				</div>
				
				<div class = "col-md-3">
				<div class = "form-group">
				 <button class = "btn btn-success" name = "change_certificate">Change </button> 
				</div>
				
				</div>	

               <div class="col-md-3" style = "display:none;">
                  <div class="form-group">
                    <input type="number"  class="form-control btn-primary"  value = "<?php echo $candidate_info['id']?>" name = "candidate_id" required="required">
                  </div>
                </div>				
		</div>	
		</form>
		<!--end change  certificate -->
		<!-- start change passport photo -->
		
		<form method = "post" action = "edit_uploads.php?eid=<?php echo $candidate_info['id']; ?>" enctype = "multipart/form-data">

		<div class = "form-row">
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "permitImage">Photo</label>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
				  <img src = "candidate_uploads/passport_photos/<?php echo $candidate_info['photo']?>" alt = "photo"width = "100px" height = "100px" style = "border-radius:40%"></img><br /><br />
					</div>
                </div>
				
				<div class = "col-md-3">
				<div class = "form-group">
				 <input class="form-control btn-primary" name = "photo"  type = "file" value = "<?php echo $candidate_info['photo'] ?>"> 
				</div>
				
				</div>
				
				<div class = "col-md-3">
				<div class = "form-group">
				 <button class = "btn btn-success" name = "change_photo">Change </button> 
				</div>
				
				</div>	

               <div class="col-md-3" style = "display:none;">
                  <div class="form-group">
                    <input type="number"  class="form-control btn-primary"  value = "<?php echo $candidate_info['id']?>" name = "candidate_id" required="required">
                  </div>
                </div>					
		</div>	
		</form>
		
		
			</div>
			<a class = "btn btn-success" href = "edit_profile.php?eid=<?php echo $candidate_info['id']?>">Edit Other Information </a> 
			</form>
			

              </div>

            </div>

           
           
          
         
        </div>
   
    </div>
	</div>
	</div>
    </div>
   </div>
    </div>
