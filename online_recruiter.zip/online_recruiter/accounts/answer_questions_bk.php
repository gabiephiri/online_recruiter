<?php require_once('includes/load.php');
$page_title = 'Jobs';
 $id = $_GET['id'];
 $job_info = find_by_id('jobs', $id);
 $all_questions = find_all('screening_questions');
 $candidate = current_user();
 $candidate_id = $candidate['id'];
 $job_name = $job_info['title'];
 ?>
  



 <!--handle multi-select and insert into a quotations table -->
  <?php
  
  //answer questions
  $selector = "SELECT * FROM screening_questions WHERE jobId = '{$id}' ORDER BY id ASC";
  $execute = $db ->query ($selector);
  
  $rowCount = mysqli_num_rows($execute);
  if (isset($_POST['submit_answers']) && isset($_POST['count'])){	  
  	$insertItemsSucess = null;

	  for ($i = 0; $i < $rowCount; $i++)
	  {
              $job_id = $_POST['job_id'];
			  $q_number= $_POST['question_id'][$i];
			  $q_answer= $_POST['answer'][$i];
			  
			  
			  $answeredQuestionInsertQuery  = "INSERT INTO screening_answers ";
			  $answeredQuestionInsertQuery .= " (jobId, questionNumber, answer, candidateId) ";
			  $answeredQuestionInsertQuery .= " VALUES ('{$job_id}','{$q_number}', '{$q_answer}', '{$candidate_id}')";
			 $insertItemsSucess =   $db->query($answeredQuestionInsertQuery); 
			 
			
	}

  

	  } 

		
  
  
  ?>
  
  <?php
if (isset($_POST['submit_answers']))
{
	//make sure that a business can only apply once for a job
	$testReapplicationQuery = "SELECT id, jobId, candidateId FROM applies_for WHERE jobId = '{$job_id}' AND candidateId = '{$candidate_id}' ";
	$executeReapplication = $db->query ($testReapplicationQuery);
	$oldReplyInfo = mysqli_fetch_array($executeReapplication);
	$lastApplyDate = $oldReplyInfo['dateAdded'];
	
	if ($db->num_rows($executeReapplication)>0)
	{
		 $session->msg('d', "We observed you already applied for this job...");
		 redirect ('jobs.php', false);
	}
	//if they have not yet applied, then okay, let the system keep the information
	else{
	
	$applyQuery = "INSERT INTO applies_for (jobId, candidateId) VALUES ('{$job_id}', '{$candidate_id}')";
	
	
	
	 if($db->query($applyQuery)){
        $session->msg("s", "Successfully applied for job ". $job_name. ' as '. $candidate['name']);
        redirect('jobs.php',false);
      }
	  else {
        $session->msg("d", "Sorry failed to apply for job.");
        redirect('jobs.php',false);
      }
   }
}


?>	

<?php include ('header.php'); ?>


      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Admin</a>
            </li>
            <li class="breadcrumb-item active">Apply for Job</li>
                          <li class="breadcrumb-item active">Take Screening Test</li>

			
          </ol>
		  
		  <div class = "col-md-12">
<?php echo display_msg($msg); ?>
</div>



        

          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
             
              <h3> <i class="fas fa-file"></i> <?php echo ucwords($job_info['title']. ' Job Aptitude (Screening) Exam') ?></h3><u>Instructions:</u> <br />1. This is a one-go exam <br />2. Answer all <strong style = 'color:red'><?php echo $rowCount; ?> </strong>questions because your business' aptitude score depends on it</div>
            <div class="card-body">
			<form method = "post" action = "answer_questions.php?id=<?php echo $job_info['id']?>">
              <div class="table-responsive">
                <table class="table table-striped" id="dataTable" width="100%" cellspacing="0">


                  <tbody>
				  <tr style = "display:none;"> 
				  <td style = "display:none;"><input type = "number" name = "job_id" value = "<?php echo $job_info['id'];?>"></td>
				   <td style = "display:none;"><input type = "text" name = "job_name" value = "<?php echo $job_info['title'];?>"></td>
				   <td style = "display:none;"><input type = "text" name = "job_name" value = "<?php echo $candidate['name'];?>"></td>				 
				   </tr>
				  

				  <?php
				  
				  
		
		$getQuestions =  "SELECT * FROM screening_questions WHERE jobId = '{$job_info['id']}'";
		$executeGet = $db->query ($getQuestions);
		 $i =0;
		 while ($a_question = mysqli_fetch_assoc($executeGet)):

		
		?>
				 
          <tr>
           <td class="text-left"><b><?php echo count_id();?></b>.&nbsp;<?php echo ucfirst($a_question['question']);?> <br />
           A : <?php echo remove_junk(ucwords($a_question['a']))?><br />
		   B : <?php echo remove_junk(ucwords($a_question['b']))?><br />
           C : <?php echo remove_junk(ucwords($a_question['c']))?><br />
           D : <?php echo remove_junk(ucwords($a_question['d']))?><br/><br/>
		   Answer : <select name = "answer[]" required = "required"><option value = "">Choose</option><option value = "A">A</option> <option value = "B">B</option><option value = "C">C</option> <option value = "D">D</option> </select>  <br /> <br />
           	<input style = "display:none"name="question_id[]" type = "number"  value="<?php echo $a_question['id'];?>" />
			<input type = "number" style = "display:none;" name = "count" value = "<?php echo $i++ ?>">

           
               
           </td>
          </tr>
        <?php endwhile;?>
       </tbody>
	 <script>  
	   $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});
</script>
                </table>
						<tr><td><button class = "btn btn-success pull-right" name = "submit_answers">Submit Answers &amp; Apply</button></td></tr>

              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

       

      </div>
      <!-- /.content-wrapper -->

    </div>

	


    <!-- Scroll to Top Button-->
  
