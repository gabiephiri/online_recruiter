<?php
	include "../includes/load.php";
	$id = $_GET['eid'];
	
	$job_info = find_by_id('jobs', $id);
	$district_info = find_by_id ('districts', $job_info['district']);
	$districtName = $district_info ['name'];
	$candidate_info = current_user();
	$candidateId = $candidate_info['id'];
?>

<?php

if (isset($_POST['apply']))
{
	$jobId = $_POST['jobIdKeeper'];
	$jobName = $_POST['jobNameKeeper'];
	
	
	//make sure that a business can only apply once for a job
	$testReapplicationQuery = "SELECT id, jobId, candidateId FROM applies_for WHERE jobId = '{$jobId}' AND candidateId = '{$candidateId}' ";
	$executeReapplication = $db->query ($testReapplicationQuery);
	$oldReplyInfo = mysqli_fetch_array($executeReapplication);
	$lastApplyDate = $oldReplyInfo['dateAdded'];
	
	if ($db->num_rows($executeReapplication)>0)
	{
		 $session->msg('d', "We observed you already applied for this job...");
		 redirect ('candidate_jobs.php', false);
	}
	//if they have not yet applied, then okay, let the system keep the information
	else{
	$applyQuery = "INSERT INTO applies_for (jobId, candidateId) VALUES ('{$jobId}', '{$candidateId}')";
	 if($db->query($applyQuery)){
        $session->msg("s", "Successfully applied for job ". $jobName. ' as '. $_SESSION['businessName']);
        redirect('candidate_jobs.php',false);
      }
	  else {
        $session->msg("d", "Sorry failed to apply for job.");
        redirect('candidate_jobs.php',false);
      }
   }
}


?>
<head><link href = "../vendor/bootstrap/css/bootstrap.css" rel = "stylesheet"></head>
<form method = "post" action = "job_info_candidate.php">
	<table class="table table-striped">
		<tr class = "pull-right">
			<th><a class="btn btn-primary" href = "answer_questions.php?id=<?php echo $job_info['id'];?>" name = "apply">Take Aptitude Test &amp; Apply</a></th>

			<input type = "number" class="btn btn-primary" name = "jobIdKeeper" style = "visibility:hidden;" value = "<?php echo $job_info['id']; ?>">
			<input type = "text" class="btn btn-primary" name = "jobNameKeeper" style = "visibility:hidden;" value = "<?php echo $job_info['title']; ?>">

			</form>
            <td></td>
		</tr>
		
		<tr>
			<th>Basic Info</th>
			<td>Job Title : <?php echo $job_info['title']; ?> <br /> Candidates Needed <?php echo $job_info['agentCount'] ?> </td>
		</tr>
		
		<tr>
			<th>Location:</th>
			<td>Trading Center : <?php echo $job_info['location']; ?><br /> District : <?php echo $districtName; ?></td>
		</tr>
		<tr>
			<th>Dates</th>
			<td>Application Close Date : <?php echo read_date($job_info['deadline'])?> <br />Date Added : <?php echo read_date($job_info['dateAdded'])?> <br /> <?php echo count_days_to_expiry($job_info['id']); ?> days to closure of application</td>
		</tr>
		<tr>
			
			<th>Job Description </th>
			<td><?php echo $job_info['jobDescription']; ?> </td>
		</tr>
		<tr>
		<th> Person Description  : </th> 
		<td><?php echo $job_info['personSpecification']; ?></td>
		</tr>
		
		
	</table>

