*******************************************************************************
DEVELOPER INFO 
********************************************************************************
Name : Gabriel Phiri
Email : gabiephiri@gmail.com
Phone : +265 881 120 438

********************************************************************************
LOGIN CREDENTIALS
*********************************************************************

EMPLOYER LOGIN
=================================================

Admin 
-----------------
username = trialadmin
password = trialadmin


Interviewer
------------------
username = trialinterviewer
password = trialinterviewer

Human Resource Manager
--------------------------------
username = trialhr
password = trialhr

/////////////////////////////////////////////////////////////////

CANDIDATE LOGIN
=================================================================
username = trialcandidate
password = trialcandidate

**********************************************************************************
DEVELOPMENT / DEPLOYMENT ENVIRONMENT
**********************************************************************************
MySQL database and PHP scripting

**********************************************************************************
DATABASE CONNECTION SCRIPT FILES
**********************************************************************************
includes/config.php 
staff/includes/config.php
accounts/incldues/config.php

**********************************************************************************
DATABASE FILE (FOR IMPORT INTO YOUR SERVER)
**********************************************************************************
Name : recruiter.sql
Location : root directory






