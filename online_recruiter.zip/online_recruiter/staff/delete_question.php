
<?php
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(3);
?>
<?php
  $delete_id = delete_by_id('screening_questions',(int)$_GET['id']);
  if($delete_id){
	  insert_act('screening question', 'deleted', '1');
      $session->msg("s","screening question deleted.");
      redirect('screening_questions.php?id='.$_GET['id']);
  } else {
	  insert_act('job', 'deleted', '0');
      $session->msg("d","failed to delete question.");
      redirect('screening_questions.php?id='.$_GET['id']);
  }
?>
