
<?php
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(3);
?>
<?php
  $delete_id = deactivate_job((int)$_GET['id']);
  if($delete_id){
	  insert_act('job', 'deleted', '1');
      $session->msg("s","job deactivated.");
      redirect('manage_jobs.php');
  } else {
	  insert_act('job', 'deleted', '0');
      $session->msg("d","sorry, job deactivation failed.");
      redirect('manage_jobs.php');
  }
?>
