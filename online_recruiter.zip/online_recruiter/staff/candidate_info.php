<?php
	include "includes/load.php";
	$candidateId = $_GET['eid'];
	$jobId = $_GET['jid'];
	$candidate_info= find_by_id('candidates', $candidateId);
	$candidate_email = $candidate_info['email_address'];
	$district_info = find_by_id('districts', $candidate_info['district']);
	$districtName = $district_info['name'];	
	$job_info = find_by_id('jobs', $jobId);
	
?>

<?php

if (isset($_POST['approve_candidate']))
{
	$cardsApprove = approve_candidate_cards($candidateId, $jobId);
	if (cardsApprove){
	    $candidate_email = mysqli_real_escape_string($db,$_POST['candidate_email']);
   
		insert_act('applicant', 'approved by cards to', '1', $userId);
		$session->msg('s', "You successfully approved candidate on behalf of the interview team");
		redirect('job_rec.php', false);
	}
	else 
	{
		insert_act('applicant', 'approved by cards', '0', $userId);
		$session->msg('d', "Sorry something went wrong while trying to approve candidate... try again or contact the administrator if the problem persists");
		redirect ('job_rec.php', false);
	}
}

if (isset($_POST['disapprove_candidate']))
{
	$cardsApprove = approve_candidate_cards($candidateId, $jobId);
	if (cardsApprove)
	{   insert_act('applicant', 'denied by interview team', '1', $userId);
		$session->msg('s', "You successfully disapproved candidate on behalf of the interview team");
		redirect('job_rec.php', false);
	}
	else 
	{
		insert_act('applicant', 'denied by interview team', '0', $userId);
		$session->msg('d', "Sorry something went wrong while trying to disapprove candidate... try again or contact the administrator if the problem persists");
		redirect ('job_rec.php', false);
	}
}

?>
<head><link href = "vendor/bootstrap/css/bootstrap.css"></head>
<div class = 'col-md-12'>
<div class = "col-md-8">
Approve / Disapprove  Candidate " <?php echo $candidate_info['first_name'] . ' '.$candidate_info['last_name']; ?> " on " <?php echo $job_info['title']; ?> " Job
  <form method = "post" action = "candidate_info.php?eid=<?php echo $candidateId;?>&jid=<?php echo $jobId;?>">
	<table class="table table-striped">
	<tr colspan = '2'>
	            <th><button class="btn btn-primary" name = "approve_candidate">Approve</th>
				 <th><button class="btn btn-warning" name = "disapprove_candidate">Disapprove</button>
				 <th style = "display:none;"><input class="form-control" name = "candidate_email" value = "<?php echo $candidate_info['email_address']?>"></th>

</tr>
</form>
		
		
		
		
			<tr><th>Name </th><td><?php echo $candidate_info['first_name'] . ' '.$candidate_info['last_name']; ?> </td></tr>
			<tr><th>Email Address </th> <td> <?php echo $candidate_info['email_address'];?> </td></tr>
			<tr><th>Phone </th> <td><?php echo $candidate_info['phone_number']; ?> </td></tr>
			<tr><th>Gender </th> <td> <?php echo $candidate_info['gender']; ?>  </th></tr>
			<tr><th>Age</th> <td> <?php echo $candidate_info['age']; ?>  </th></tr>
			<tr><th>District </th> <td><?php echo $districtName ?> </th></tr>
			<tr><th>Location </th> <td> <?php echo $candidate_info['location']; ?> </td></tr>
		
		
		
		
		
		
	</table>
<script src = "../vendor/bootstrap/js/bootrap.js"></script>
  <script src="../vendor/sweetalert/sweetalert.js"></script>

</div>

</div>