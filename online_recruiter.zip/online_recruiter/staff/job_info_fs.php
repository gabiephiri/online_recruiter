<?php
	include "includes/load.php";
	$id = $_GET['eid'];
	$job_info = find_by_id('jobs', $id);
	$district_info = find_by_id ('districts', $job_info['district']);
	$districtName = $district_info ['name'];
	$count_days_to_expiry = count_days_to_expiry($id);
	
	
?>

<?php


?>
<?php include ('hr_header.php') ?>
	<table class="table table-striped">
	<tr>
	            <th><button class="btn btn-warning"><a href = "edit_job.php?id=<?php echo $job_info['id']; ?>" style = "text-decoration:none; color:white !important">Edit</button></a></th>
				 <th><button class="btn btn-danger" onclick = "deleteJob('<?php echo $job_info['id']; ?>')">Delete</button>
				 <button class="btn btn-success"><a href = "jobs.php" style = "text-decoration:none; color:white !important">Tablular View</button></a></th>

</tr>
		
		
		<tr>
			<th>Basic Info</th>
			<td>Job Title : <?php echo $job_info['title']; ?> <br /> Agents Needed : <?php echo $job_info['agentCount'] ?> </td>
		</tr>
		
		<tr>
			<th>Location:</th>
			<td>Trading Center : <?php echo $job_info['location']; ?><br /> District : <?php echo $districtName; ?></td>
		</tr>
		<tr>
			<th>Dates</th>
			<td>Application Close Date : <?php echo read_date($job_info['deadline'])?> <br />Date Added: <?php echo read_date($job_info['dateAdded'])?> <br /> <?php echo $count_days_to_expiry; ?> days to close </td>
		</tr>
		<tr>
			
			<th>Job Description </th>
			<td><?php echo $job_info['jobDescription']; ?> </td>
		</tr>
		<tr>
		<th> Person Description  : </th> 
		<td><?php echo $job_info['personSpecification']; ?></td>
		</tr>
		
	</table>
<script src = "../vendor/bootstrap/js/bootrap.js"></script>
  <script src="../vendor/sweetalert/sweetalert.js"></script>
		<script src="../vendor/sweetalert/sweetalert-dev.js"></script>
<script type="text/javascript">
function deleteJob(x){
sweetAlert({   title: "Proceed to delete job?!",
                                text: "job will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_job.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } });
}
</script>
