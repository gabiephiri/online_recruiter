 
<?php include("includes/load.php");
$user = current_user();
 ?>
 <?php
 $countActs= count_by_id('acts_log');
 $totalActs = $countActs['total'];
 
 
 
 $all_acts = find_all ('acts_log');
 
 
 
 
 
 ?>
<?php
	include('admin_header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header">
       <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Admin</a>
            </li>
            <li class="breadcrumb-item active">Manage User Acts</li>
			<li class="breadcrumb-item active">All Acts</li>
			<li class="breadcrumb-item pull-right">
			

            </li>

          </ol>
		</div>
		
		<div class="page-header">
       <ol class="breadcrumb">

            <li class = "breadcrumb-item"> <b style = "color:green">{All Acts: <?php echo $totalActs; ?>}</b> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;
			            <li> <button class = "btn btn-danger pull-right"onclick = "clearLog(); return false;">Clear Log </button>

			</li>
			
          </ol>
		</div>
        <div class="row">
		<!-- start with table of users -->
		
		 <div class="col-md-12">
            <table class="table table-striped" id = "dataTable" cellspacing = "0">
			
              <tbody>
			  
			  <?php foreach ($all_acts as $an_act) :
			  $actor_info = find_by_id ('users', $an_act['actor']);
			  $actorName = $actor_info ['title']. ' '. $actor_info['first_name']. ' '.$actor_info['other_names']. ' '. $actor_info['last_name'];
			  
			  if ($an_act['status'] === '1'): 
			  ?>
			   <tr>
			   
			   <td> 
			  <span class = "badge badge-success"> <?php echo count_id(); ?> </span> <?php echo $an_act['object']. ' '. $an_act['action']. ' by '. $actorName. ' ON '. read_date($an_act ['dateAdded']); ?>
			   <td>
                  
                </tr>
				
				
				<?php else: 
                    $act_text_length = strlen($an_act['action']);
					$act_word = substr($an_act['action'], 0, ($act_text_length - 2));
					
					
				?>
				
				<tr>
			   
			   <td> 
			  <span class = "badge badge-warning"> <?php echo count_id(); ?> </span> <?php echo $actorName. ' failed to '. $act_word. ' a '. $an_act['object']. ' on '. read_date($an_act ['dateAdded']); ?>
			   <td>
                  
                </tr>
				
				<?php endif; ?>
				
				
				<?php endforeach; ?>
			  
			  </tbody>		
         </table>

          </div>
		
	<!-- end of table -->

         
		  </div>
		  
        </div>
      </div>
	  </div>
	  </div>

    </div><!-- /.container -->
 
          

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	
	<script type="text/javascript">
function clearLog(){
sweetAlert({   title:"<?php echo ucfirst($user['username']);?> proceed to clear activity log!",
                                text: "all acts records will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_log.php";   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } });
}
</script>
  </body>
  
</html>
