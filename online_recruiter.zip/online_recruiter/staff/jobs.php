<?php require_once('includes/load.php');
$page_title = 'Jobs';
 page_require_level(4);
 $all_vacancies = find_all_jobs();
 ?>
<?php include ('hr_header.php'); ?>

      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Admin</a>
            </li>
            <li class="breadcrumb-item active">Manage Jobs</li>
			<?php if (is_hr()): ?>
              <li class="breadcrumb-item">
              <a href="add_job.php">Add Job</a>
            </li>
			<?php endif; ?>
			<li class="breadcrumb-item">
              <a href="manage_jobs.php">List View</a>
            </li>
          </ol>



        

          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-users"></i>
              All Jobs</div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>#</th>
					  <th class = "text-center">Candidates Needed</th>
                      <th class = "text-center">Title</th>    
					  <th class = "text-center">Location</th>
					   <th class = "text-center">District</th>
                      <th class = "text-center">Job Description</th>
					  <th class = "text-center">Person Spec</th>
					  <th class = "text-center">Deadline</th>
					  <th class = "text-center">Created</th>
                    </tr>
                  </thead>
                  <tfoot>
				   <tr>
					  <th>#</th>
					  <th class = "text-center">Candidates Needed</th>
                      <th class = "text-center">Title</th>
					  <th class = "text-center">Location</th>
					   <th class = "text-center">District</th>
                      <th class = "text-center">Job Description</th>
					  <th class = "text-center">Person Spec</th>
					  <th class = "text-center">Deadline</th>
					  <th class = "text-center">Created</th>
                    </tr>
                    
                  </tfoot>

                  <tbody>
				<?php foreach($all_vacancies as $a_job): ?>
          <tr>
           <td class="text-center"><?php echo count_id();?></td>
		    <td class="text-center"><?php echo remove_junk(ucwords($a_job['agentCount']))?></td>
           <td class = "text-left"><?php echo remove_junk(ucwords($a_job['title']))?></td>
		   <td class="text-left"><?php echo remove_junk(ucwords($a_job['location']))?></td>
           <td class = "text-left"><?php echo remove_junk(ucwords($a_job['district']))?></td>
           <td class="text-left"><?php echo remove_junk(ucwords($a_job['jobDescription']))?></td>
		   <td class="text-left"><?php echo remove_junk(ucwords($a_job['personSpecification']))?></td>
		   <td class="text-left"><?php echo read_date(ucwords($a_job['deadline']))?></td>
	      <td class="text-left"><?php echo read_date(ucwords($a_job['dateAdded']))?></td>
		  <?php
		 if (is_hr()):
		  ?>
           <td class="text-left">
             <div class="btn-group">
			  <a href="job_info_fs.php?eid=<?php echo (int)$a_job['id'];?>" class="btn btn-xs btn-primary" data-toggle="tooltip" data-placement= "bottom" title="Info & Apply">
                  <i class="fa fa-info"></i>
               </a>
                <a href="edit_job.php?id=<?php echo (int)$a_job['id'];?>" class="btn btn-xs btn-warning" data-toggle="tooltip" title="Edit">
                  <i class="fa fa-edit"></i>
               </a>
                <a onclick ="deleteJob(<?php echo$a_job['id']?>)" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Remove">
                  <i class="fa fa-trash"></i>
                </a>
                </div>
           </td>
		   <?php endif; ?>
          </tr>
        <?php endforeach;?>
       </tbody>
	 <script>  
	   $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});
</script>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

       

      </div>
      <!-- /.content-wrapper -->

    </div>
	
<script type="text/javascript">
function deleteJob(x){
sweetAlert({   title: "Proceed to delete job?!",
                                text: "job will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_job.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } });
}
</script>
	
	
	
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
  
