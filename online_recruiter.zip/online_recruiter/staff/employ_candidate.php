
<?php
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
  $candidate_id = $_GET['cid'];
  $job_id = $_GET['jid'];
  $candidate_info = find_by_id ('candidates', $candidate_id);
  $candidate_email = $candidate_info['emailAddress'];
  
  if (!$job_id)
  {
    $session->msg ("d", "Missing job id");
	redirect ('jobs.php', false);
  }
  
   if (!$candidate_id)
  {
    $session->msg ("d", "Missing job id");
		redirect ('view_rank.php?jid='.$job_id, false);

}
else 
{

$employQuery = "INSERT INTO employed_candidates (jobId, candidateId) VALUES ('{$job_id}', '{$candidate_id}')";
$executeInsert = $db->query ($employQuery);
 if ($employQuery)
 {
    mail($candidate_email,"Employed by NBMORE", "Congrats, you have been successfully employed by NBM as an Agent... Go to the nearest NBM branch to get your tools" );
 $session->msg ('s', "Agent Successfully Employed");
 redirect ('view_rank.php?jid='.$job_id, false);
 }
 else 
 {
 $session->msg ('d', "Employing agent failed");
 redirect ('view_rank.php?jid='.$job_id, false);
 }
 }
?>
