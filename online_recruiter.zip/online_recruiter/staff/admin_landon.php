<?php
  $page_title = 'Admin Home Page';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(1);
?>
<?php
 $c_categorie     = count_by_id('categories');
 $c_product       = count_by_id('products');
 $c_sale          = count_by_id('sales');
 $c_user          = count_by_id('users');
 $c_office        = count_by_id('offices');
 $c_service      = count_by_id('services');
 $c_subservice   = count_by_id('subservices');
 $c_message      = count_by_id('messages');
 $c_quotation = count_by_id('quotations');
 $c_act      = count_by_id('acts_log');
 $c_about = count_by_id('company_info');
  $c_group = count_by_id('user_groups');
  
  $recent_messages = find_all_limited('messages', 10);


 
 $products_sold   = find_higest_saleing_product('10');
 $recent_products = find_recent_product_added('5');
 $recent_sales    = find_recent_sale_added('5')

?>
<?php include ('layouts/lte_header.php'); ?>
<head>
  <link rel="stylesheet" href="../admin_lte/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../admin_lte/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="../admin_lte/bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../admin_lte/dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../admin_lte/dist/css/skins/_all-skins.min.css">
</head>
    <div id="wrapper">

      <div id="content-wrapper">

        <div class="container-fluid"  margin-top = "3%">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Overview</li>
			
          </ol>
		 

          <!-- Icon Cards-->
          <div class="row" style = "height:20%">
		   <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-primary o-hidden h-100">
			   <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-fw fa-users"></i>
                  </div>
                  <div class="mr-5"><?php echo $c_user['total'];?> &nbsp;Users</div>
				   <div class="mr-5"><?php echo $c_group['total'];?> &nbsp;Groups</div>


                </div>
			
                <a class="card-footer text-white clearfix small z-1" href="groups.php">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
           
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-warning o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-fw fa-list"></i>
                  </div>
                  <div class="mr-5"><?php echo $c_sale['total']; ?>&nbsp; Sales</div>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="sales.php">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-success o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-fw fa-shopping-cart"></i>
                  </div>
                  <div class="mr-5"><?php echo $c_product['total']; ?> &nbsp; Products</div>
				  <div class="mr-5"><?php echo $c_categorie['total']; ?> &nbsp; Product Groups</div>

                </div>
                <a class="card-footer text-white clearfix small z-1" href="products.php">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
			
             <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-danger o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-fw fa-wrench"></i>
                  </div>
                  <div class="mr-5"><?php echo $c_service['total'];?> &nbsp;Services</div>
				   <div class="mr-5"><?php echo $c_subservice['total'];?> &nbsp;Subservices</div>

                </div>
                <a class="card-footer text-white clearfix small z-1" href="subservices.php">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
			
          </div>
		  </div>
<div class = "col-md-12">  &nbsp; </div>
<div class = "col-md-12">

  <div class="col-md-6">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="fa fa-th"></span>
          <span>Recently Added Products</span>
        </strong>
      </div>
      <div class="panel-body">

        <div class="list-group">
      <?php foreach ($recent_products as  $recent_product): ?>
            <a class="list-group-item clearfix" href="edit_product.php?id=<?php echo    (int)$recent_product['id'];?>">
                <h4 class="list-group-item-heading">
                 
                  <img class="img-avatar img-circle" src="../images/products/<?php echo $recent_product['image'];?>" alt="" />
      
                <?php echo remove_junk(first_character($recent_product['name']));?>
                  <span class="label label-success pull-right">
                 MK <?php echo number_format((int)$recent_product['sale_price'], 2); ?>
                  </span>
                </h4>
                <span class="list-group-item-text pull-right">
		
                <?php 
				$find_product_category = find_by_id ('categories', (int) $recent_product['id']);
				$categoryName = $find_product_category['name'];
				
				echo remove_junk(first_character($categoryName)); ?>
              </span>
          </a>
      <?php endforeach; ?>
    </div>
  </div>
 </div>
</div>
               <div class="col-md-6">
              <!-- DIRECT CHAT -->
              <div class="box box-warning direct-chat direct-chat-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">Latest Messages</h3>

                  <div class="box-tools pull-right">
                    <span data-toggle="tooltip" title="10 Latest Messages" class="badge bg-yellow"><?php echo $c_message['total'];?>+</span>
                    </button>
                    <input class="btn btn-box-tool" data-toggle="tooltip" title="View all Messages"
                            data-widget="chat-pane-toggle">
                      <a href = "messages_chat.php" title = "View All" data-toggle = "tooltip" data-placement = "bottom"><i class="fa fa-fullscreen"></i></button></a>
                    </input>
                  </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                  <!-- Conversations are loaded here -->
                  <div class="direct-chat-messages">
                    <!-- Message. Default to the left -->
					
					<?php foreach($recent_messages as $a_message):
                          if (((int)$a_message['id']% 2)=== 0)	:
					?>
                    <div class="direct-chat-msg right">
                      <div class="direct-chat-info clearfix">
                        <span class="direct-chat-name pull-left"><?php echo $a_message['firstName']. ' '. $a_message['lastName']; ?></span>
                        <span class="direct-chat-timestamp pull-right">&lt;<?php echo $a_message['emailAddress']. '> '. read_date($a_message['dateAdded']); ?></span>
						<span class="direct-chat-name pull-left" style = "color:blue">&nbsp; <?php echo " ". $a_message['subject'];?></span>

                      </div>
                      <!-- /.direct-chat-info -->
                      <img class="direct-chat-img" src="../../admin_lte/dist/img/avatar3.png" alt="message user image">
                      <!-- /.direct-chat-img -->
                      <div class="direct-chat-text">
                        <?php echo $a_message['message']; ?>
                      </div>
                      <!-- /.direct-chat-text -->
                    </div>
					<?php else : ?>
                    <!-- /.direct-chat-msg -->

                    <!-- Message to the right -->
                    <div class="direct-chat-msg">
                      <div class="direct-chat-info clearfix">
                        <span class="direct-chat-name pull-right"><?php echo $a_message['firstName']. ' '. $a_message['lastName']; ?></span>
                        <span class="direct-chat-timestamp pull-left">&lt;<?php echo $a_message['emailAddress']. '> '. read_date($a_message['dateAdded']); ?></span>
						<span class="direct-chat-name pull-left" style = "color:red">&nbsp; <?php echo $a_message['subject'];?></span>

                      </div>
                      <!-- /.direct-chat-info -->
                      <img class="direct-chat-img" src="../../admin_lte/dist/img/avatar04.png" alt="message user image">
                      <!-- /.direct-chat-img -->
                      <div class="direct-chat-text disabled">
                         <?php echo $a_message['message']; ?>
                      </div>
                      <!-- /.direct-chat-text -->
                    </div>
					<?php endif; ?>
                    <!-- /.direct-chat-msg -->
				   <?php endforeach; ?>

                  </div>
				  
                  <!--/.direct-chat-messages-->

  
                  <!-- /.direct-chat-pane -->
                </div>
                <!-- /.box-body -->
               
                <!-- /.box-footer-->
              </div>
              <!--/.direct-chat -->
            </div>
			
			   <div class="col-md-6">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="fa fa-clock-o"></span>
            <span>LATEST SALES</span>
          </strong>
        </div>
        <div class="panel-body">
          <table class="table table-striped table-bordered table-condensed">
       <thead>
         <tr>
           <th class="text-center" style="width: 50px;">#</th>
           <th>Product Name</th>
           <th>Date</th>
           <th>Total Sale (MK)</th>
         </tr>
       </thead>
       <tbody>
         <?php foreach ($recent_sales as  $recent_sale): ?>
         <tr>
           <td class="text-center"><?php echo count_id();?></td>
           <td>
            <a href="edit_sale.php?id=<?php echo (int)$recent_sale['id']; ?>">
             <?php echo remove_junk(first_character($recent_sale['name'])); ?>
           </a>
           </td>
           <td><?php echo read_date($recent_sale['dateAdded']); ?></td>
           <td>MK <?php echo number_format($recent_sale['selling_price']); ?></td>
        </tr>

       <?php endforeach; ?>
       </tbody>
	   <script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});
</script>

     </table>
    </div>
   </div>
 

        </div>
        <!-- /.container-fluid -->

       
      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    

  </body>

</html>
