<?php require_once('includes/load.php');
$page_title = 'Jobs';
 page_require_level(2);
 $id = $_GET['id'];
 $job_info = find_by_id('jobs', $id);
 $all_questions = find_all('screening_questions');
 $candidate = current_user();
 $candidate_id = $candidate['id'];
 ?>
  



 <!--handle multi-select and insert into a quotations table -->
  <?php
  $selector = "SELECT * FROM screening_questions WHERE jobId = '{$id}' ORDER BY id ASC";
  $execute = $db ->query ($selector);
  
  $rowCount = mysqli_num_rows($execute);
  if (isset($_POST['submit_answers']) && isset($_POST['count'])){	  
  	$insertItemsSucess = null;

	  for ($i =0; $i < $rowCount; $i++)
	  {
              $job_id = $_POST['job_id'];
			  $q_number= $_POST['question_id'][$i];
			  $q_answer= $_POST['answer'][$i];
			  
			  
			  $answeredQuestionInsertQuery  = "INSERT INTO screening_answers ";
			  $answeredQuestionInsertQuery .= " (jobId, questionNumber, answer, candidateId) ";
			  $answeredQuestionInsertQuery .= " VALUES ('{$job_id}','{$q_number}', '{$q_answer}', '{$candidate_id}')";
			 $insertItemsSucess =   $db->query($answeredQuestionInsertQuery); 
			 
			
	}
  
 if ($insertItemsSucess)
		{
			$session->msg ("s", "Answers submitted successfully");
			redirect('answer_questions.php?id='.$job_info['id'], false);
		}	
	else 
			{
				$session->msg ("d", "failed to submit answers...try again. if the problem persists, contact the NBMORE!");
				redirect('answer_questions.php?id='.$job_info['id'], false);
			}
			 
	  } 

		
  
  
  ?>
<?php include ('hr_header.php'); ?>


      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Admin</a>
            </li>
            <li class="breadcrumb-item active">Manage Jobs</li>
              <li class="breadcrumb-item">
              <a href="manage_screening.php?id=<?php echo $id?>">Add Question</a>
            </li>
			
          </ol>
		  
		  <div class = "col-md-12">
<?php echo display_msg($msg); ?>
</div>



        

          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
             
              <h3> <i class="fas fa-users"></i> <?php echo ucwords($job_info['title']. ' Job Aptitude (Screening) Exam') ?></h3><u>Instructions:</u> <br />1. This is a one-go exam <br />2. Answer all <strong style = 'color:red'><?php echo $rowCount; ?> </strong>questions because your business' aptitude score depends on it</div>
            <div class="card-body">
			<form method = "post" action = "answer_questions.php?id=<?php echo $job_info['id']?>">
              <div class="table-responsive">
                <table class="table table-striped" id="dataTable" width="100%" cellspacing="0">


                  <tbody>
				  <tr style = "display:none;"> <td><input type = "number" name = "job_id" value = "<?php echo $job_info['id']?>"></td><tr>
				  <?php
				  $i =0;
				 foreach($all_questions as $a_question): ?>
          <tr>
           <td class="text-left"><b><?php echo count_id();?></b> . <?php echo ucfirst($a_question['question'])?> <br />
           A : <?php echo remove_junk(ucwords($a_question['a']))?><br />
		   B : <?php echo remove_junk(ucwords($a_question['b']))?><br />
           C : <?php echo remove_junk(ucwords($a_question['c']))?><br />
           D : <?php echo remove_junk(ucwords($a_question['d']))?><br/><br/>
		   Answer : <select name = "answer[]" required = "required"><option value = "">Choose</option><option value = "A">A</option> <option value = "B">B</option><option value = "C">C</option> <option value = "D">D</option> </select>  <br /> <br />
           	<input style = "display:none"name="question_id[]" type = "number"  value="<?php echo $a_question['id'];?>" />
			<input type = "number" style = "display:none;" name = "count"value = "<?php echo $i++ ?>">

           
               
           </td>
          </tr>
        <?php endforeach;?>
		<tr><td><button class = "btn btn-success pull-right" name = "submit_answers">Submit Answers</button></td></tr>
       </tbody>
	 <script>  
	   $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});
</script>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

       

      </div>
      <!-- /.content-wrapper -->

    </div>


    <!-- Scroll to Top Button-->
  
