<?php include ('includes/load.php');
$page_title = "Employed Candidates";
 
 $job_id = $_GET['jid'];
 $job_info = find_by_id ('jobs', $job_id);
 ?>
<?php include ('recunit_header.php'); ?>

      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Recruiter</a>
            </li>
            <li class="breadcrumb-item active">Employed Candidates</li>
          </ol>



        

          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-users"></i>
              Empoyeed Agents on Job  <?php $job_info ['title'] ?> </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					<th>#</th>
                      <th class = "text-center">Name</th>
					   
                      
                    </tr>
                  </thead>
                  <tfoot>
				  <tr>
				      <th># </th>
					 <th class = "text-center">Name</th>
                      
                    </tr>
                    
                  </tfoot>

                  <tbody>
				<?php 
				
				$agentsQuery = "SELECT * FROM employed_candidates WHERE jobId = {$job_id}";
				$executeSelected = $db->query($agentsQuery);
				
				while ($employed_candidate = mysqli_fetch_assoc ($executeSelected)):
				
				$candidate_info = find_by_id ('candidates', $employed_candidate['candidateId']);
				$candidate_name = $candidate_info['name'];
				
				
				
				?>
          <tr>
           <td class="text-center"><?php echo count_id();?></td>
           <td class = "text-center"><?php echo $candidate_name ?></td>
          

          
     
          </tr>
        <?php endwhile;?>
       </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

       

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
  
