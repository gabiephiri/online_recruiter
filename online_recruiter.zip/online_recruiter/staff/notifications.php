 
<?php include("includes/load.php");
$user = current_user();
 ?>
 <?php
 $all_notes= find_all_my_messages();
 $count_my_notes = count_my_messages();
 
 
 
 
 
 ?>
<?php
	include('admin_header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header">
       <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">NBMORE Staff</a>
            </li>
            <li class="breadcrumb-item active">Notifications</li>
			<li class="breadcrumb-item active">My Notification Box</li>
			

            </li>

          </ol>
		</div>
		
		<div class="page-header">
       <ol class="breadcrumb">

            <li class = "breadcrumb-item"> <b style = "color:green">{All Notifications: <?php echo $count_my_notes['total']; ?>}</b> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;

			</li>
			<li class="breadcrumb-item">
              <a href="send_note.php">Send Message</a>
            </li>
			
          </ol>
		</div>
        <div class="row">
		<!-- start with table of users -->
		
		 <div class="col-md-12">
            <table class="table table-striped" id = "dataTable" cellspacing = "0">
			
              <tbody>
			  
			  <?php foreach ($all_notes as $a_note) :
			  $user =current_user ();
			  $my_id = $user['id'];
			  $sender_info = find_by_id ('users', $a_note['sender']);
			  $receiver_info = find_by_id('users', $a_note['recepient']);
			  $receiver_name = $receiver_info['first_name']. ' '. $receiver_info['last_name'];
			  
			  $actorName = $sender_info['first_name']. ' '. $sender_info['last_name'];
			  
			  
			  if ($a_note['sender'] === $my_id): 
			  ?>
			   <tr>
			   
			   <td> 
			  OUTBOX: <span class = "badge badge-success"> <?php echo count_id(); ?> </span><b> <?php echo $a_note['subject'] ?> </b><?php echo ' '. $a_note['message']. ' {to '?> <b><i style = "color:green"><?php echo $receiver_name; ?> }</i></b> ON  <b style = "color:red"?> <?php echo read_date($a_note ['dateAdded']); ?></b>
			   <td>
                  
                </tr>
				
				
				<?php else:?>
				
				<tr>
			   
			   <td> 
			 INBOX <span class = "badge badge-warning"> <?php echo count_id(); ?> </span><b style = "color:green"><i> {<?php echo $actorName; ?>}</i></b> said <b><?php echo $a_note['subject']?></b> <?php echo $a_note['message'] . ' on ' ?> <b style = "color:red"><?php echo read_date($a_note ['dateAdded']); ?>
			   <td>
                  
                </tr>
				
				<?php endif; ?>
				
				
				<?php endforeach; ?>
			  
			  </tbody>		
         </table>

          </div>
		
	<!-- end of table -->

         
		  </div>
		  
        </div>
      </div>
	  </div>
	  </div>

    </div><!-- /.container -->
 
          

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	
	<script type="text/javascript">
function clearLog(){
sweetAlert({   title:"<?php echo ucfirst($user['username']);?> proceed to clear activity log!",
                                text: "all acts records will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_log.php";   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } });
}
</script>
  </body>
  
</html>
