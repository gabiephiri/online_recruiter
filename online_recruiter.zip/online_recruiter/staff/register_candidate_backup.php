 
<?php include("includes/load.php");
$all_districts = find_all('districts');

$page_title = 'Candidate Registration';
 ?>
 <?php
  
  if (isset($_POST['submit_candidate']))
  {

   $req_field = array('businessName', 'businessUserName', 'businessType','businessPhoneNumber','businessPassword', 'businessLocation', 'businessDistrict',
   'dailyCustomers', 'dailySales','managerName', 'assistant1Name', 'assistant2Name');
      
	  
	  $businessName = remove_junk($db->escape($_POST['businessName']));
   $businessUserName = remove_junk($db->escape($_POST['businessUserName']));
   $businessType = remove_junk($db->escape($_POST['businessType']));
   $businessPhoneNumber = remove_junk($db->escape($_POST['businessPhoneNumber']));
      $businessPostalAddress = remove_junk($db->escape($_POST['businessPostalAddress']));

   $businessEmailAddress = remove_junk($db->escape($_POST['businessEmailAddress']));
   $password= remove_junk($db->escape($_POST['businessPassword']));
   
   //hash lowercase username into password
   $lowerCaseUserName= strtolower($businessUserName);
   $businessPassword = sha1($lowerCaseUserName);
	

   $businessLocation = remove_junk($db->escape($_POST['businessLocation']));
   $businessDistrict = remove_junk($db->escape($_POST['businessDistrict'])); 
   $dailyCustomers = remove_junk($db->escape($_POST['dailyCustomers']));
   $dailySales = remove_junk($db->escape($_POST['dailySales']));
   $managerName = remove_junk($db->escape($_POST['managerName']));
   $assistant1Name = remove_junk($db->escape($_POST['assistant1Name']));
      $assistant2Name = remove_junk($db->escape($_POST['assistant2Name']));

   
   //limited company information
   $commercialActivityNotes = remove_junk($db->escape($_POST['commercialActivityNotes']));
   $boardResolution = remove_junk($db->escape($_POST['boardResolution']));
   
   //handling uploads
	
	//firstly file names
     $businessPremisesImage = rand(1000, 100000)."-".$_FILES ['businessPremisesImage']['name'];
	 $businessPermitImage = rand(1000, 100000)."-".$_FILES ['businessPermitImage']['name'];
	 $tpin=  rand(1000, 100000)."-".$_FILES ['tpin']['name'];  
	 $incorporationCertificate =  rand(1000, 100000)."-".$_FILES ['incorporationCertificate']['name'];
	 $directorImage =  rand(1000, 100000)."-".$_FILES ['directorImage']['name'];


	 

	 
	$managerCV =  rand(1000, 100000)."-".$_FILES ['managerCV']['name'];
	$managerPassportPhoto =  rand(1000, 100000)."-".$_FILES ['managerPassportPhoto']['name'];
    $managerCertificate=  rand(1000, 100000)."-".$_FILES ['managerCertificate']['name'];
	
	$assistant1CV=  rand(1000, 100000)."-".$_FILES ['assistant1CV']['name'];
    $assistant1PassportPhoto =  rand(1000, 100000)."-".$_FILES ['assistant1PassportPhoto']['name'];
    $assistant1Certificate =  rand(1000, 100000)."-".$_FILES ['assistant1Certificate']['name'];
	
	$assistant2CV =  rand(1000, 100000)."-".$_FILES ['assistant2CV']['name'];
	$assistant2PassportPhoto =  rand(1000, 100000)."-".$_FILES ['assistant2PassportPhoto']['name'];
	$assistant2Certificate =  rand(1000, 100000)."-".$_FILES ['assistant2Certificate']['name'];
	
   
   //temporary files
    $businessPremisesImageTempFile = $_FILES['businessPremisesImage']['tmp_name'];
	 $businessPermitImageTempFile = $_FILES['businessPermitImage']['tmp_name'];
	 $incorporationCertificateTempFile = $_FILES['incorporationCertificate'] ['tmp_name'];

    $tpinTempFile = $_FILES['tpin']['tmp_name'];
	$directorImageTempFile = $_FILES['directorImage']['tmp_name'];

    $managerCVTempFile = $_FILES['managerCV']['tmp_name'];
	$managerPassportPhotoTempFile = $_FILES['managerPassportPhoto']['tmp_name'];
	$managerCertificateTempFile = $_FILES['managerCertificate']['tmp_name'];
	
	$assistant1CVTempFile = $_FILES['assistant1CV']['tmp_name'];
	$assistant1PassportPhotoTempFile = $_FILES['assistant1PassportPhoto']['tmp_name'];
	$assistant1CertificateTempFile = $_FILES['assistant1Certificate']['tmp_name'];
	
	$assistant2CVTempFile = $_FILES['assistant2CV']['tmp_name'];
	$assistant2PassportPhotoTempFile = $_FILES['assistant2PassportPhoto']['tmp_name'];
    $assistant2CertificateTempFile = $_FILES['assistant2Certificate']['tmp_name'];
	
	//folder locations
	
    $premisesImagesFolder="images/candidate_uploads/premises_images/"; //premises images
	$tpinsFolder="images/candidate_uploads/tpins/"; //tpins 
    $passportPhotosFolder="images/candidate_uploads/passport_photos/"; //passport photos and ID images for directors, managers and assistants
	$certificatesFolder="images/candidate_uploads/certificates/"; //cvs business permits, and certificates for directors, managers and assistants
	
	//lowercase file names for compatibility
	
		$lowercaseBusinessPremisesImage= strtolower($businessPremisesImage);
		$lowercaseBusinessPermitImage = strtolower($businessPermitImage);
		$lowercaseIncorporationCertificate = strtolower ($incorporationCertificate);
		$lowercaseTpin= strtolower($tpin);
		$lowercaseDirectorImage= strtolower($directorImage);
		
		$lowercaseManagerCV= strtolower($managerCV);
		$lowercaseManagerPassportPhoto= strtolower($managerPassportPhoto);
		$lowercaseManagerCertificate= strtolower($managerCertificate);
		
		$lowercaseAssistant1CV= strtolower($assistant1CV);
		$lowercaseAssistant1PassportPhoto= strtolower($assistant1PassportPhoto);
		$lowercaseAssistant1Certificate= strtolower($assistant1Certificate);
		
		$lowercaseAssistant2CV= strtolower($assistant2CV);
		$lowercaseAssistant2PassportPhoto= strtolower($assistant2PassportPhoto);
		$lowercaseAssistant2Certificate= strtolower($assistant2Certificate);
		
		$finalBusinessPremises = str_replace(' ','-',$lowercaseBusinessPremisesImage);
		$finalBusinessPermit = str_replace(' ','-',$lowercaseBusinessPermitImage);
		$finalIncorporationCertificate= str_replace(' ','-',$lowercaseIncorporationCertificate);


		$finalTpin = str_replace(' ','-',$lowercaseTpin);
		$finalDirectorImage = str_replace(' ','-',$lowercaseDirectorImage);
		
		$finalManagerCV = str_replace(' ','-',$lowercaseManagerCV);
		$finalManagerPassportPhoto = str_replace(' ','-',$lowercaseManagerPassportPhoto);
		$finalManagerCertificate= str_replace(' ','-',$lowercaseManagerCertificate);

		
		$finalAssistant1CV = str_replace(' ','-',$lowercaseAssistant1CV);
		$finalAssistant1PassportPhoto = str_replace(' ','-',$lowercaseAssistant1PassportPhoto);	
		$finalAssistant1Certificate = str_replace(' ','-',$lowercaseAssistant1Certificate);
			
		$finalAssistant2CV = str_replace(' ','-',$lowercaseAssistant2CV);
		$finalAssistant2PassportPhoto= str_replace(' ','-',$lowercaseAssistant2PassportPhoto);
		$finalAssistant2Certificate = str_replace(' ','-',$lowercaseAssistant2Certificate);

   
   if ((empty($errors)) 
	 AND (move_uploaded_file($businessPremisesImageTempFile, $certificatesFolder.$finalBusinessPremises))
     AND (move_uploaded_file($businessPermitImageTempFile, $premisesImagesFolder.$finalBusinessPermit))
     AND (move_uploaded_file($tpinTempFile, $tpinsFolder.$finalTpin)) 
	 AND (move_uploaded_file($managerCVTempFile, $certificatesFolder.$finalManagerCV))
	 AND (move_uploaded_file($managerPassportPhotoTempFile, $passportPhotosFolder.$finalManagerPassportPhoto))
	 AND (move_uploaded_file($managerCertificateTempFile, $certificatesFolder.$finalManagerCertificate))
	 
	 AND (move_uploaded_file($assistant1CVTempFile, $certificatesFolder.$finalAssistant1CV))
	 AND (move_uploaded_file($assistant1PassportPhotoTempFile, $passportPhotosFolder.$finalAssistant1PassportPhoto))
	 AND (move_uploaded_file($assistant1CertificateTempFile, $certificatesFolder.$finalAssistant1Certificate))
	 
	 AND (move_uploaded_file($assistant2CVTempFile, $certificatesFolder.$finalAssistant2CV))
	 AND (move_uploaded_file($assistant2PassportPhotoTempFile, $passportPhotosFolder.$finalAssistant2PassportPhoto))
	 AND (move_uploaded_file($assistant2CertificateTempFile, $certificatesFolder.$finalAssistant2Certificate))
  
  )
  {
	  
	  $insertCandidateQuery = "INSERT INTO candidates (
	                            businessName, businessUserName,businessType, businessEmailAddress, businessPassword, businessPhoneNumber,
	                           businessPostalAddress, businessDistrict, businessLocation, dailyCustomers, dailySales,
                                businessPremisesImage, businessPermitImage, tpin, 
								managerName, managerCV, managerPassportPhoto, managerCertificate, 
								assistant1Name, assistant1CV, assistant1PassportPhoto, assistant1Certificate,
								assistant2Name, assistant2CV, assistant2PassportPhoto, assistant2Certificate,
								
								incorporationCertificate, commercialActivityNotes, directorIdImage, boardResolution
								)";
								
	$insertCandidateQuery .= " VALUES (
	                           '{$businessName}', '{$businessUserName}', '{$businessType}', '{$businessEmailAddress}', '{$businessPassword}', '{$businessPhoneNumber}',
							   '{$businessPostalAddress}', '{$businessDistrict}', '{$businessLocation}', '{$dailyCustomers}', '{$dailySales}',
							   '{$finalBusinessPremises}', '{$finalBusinessPermit}', '{$finalTpin}',
							   
							   '{$managerName}', '{$finalManagerCV}', '{$finalManagerPassportPhoto}', '{$finalManagerCertificate}',
							   '{$assistant1Name}', '{$finalAssistant1CV}', '{$finalAssistant1PassportPhoto}', '{$finalAssistant1Certificate}',
							   '{$assistant2Name}', '{$finalAssistant2CV}', '{$finalAssistant2PassportPhoto}', '{$finalAssistant2Certificate}',
							   
							   '{$finalIncorporationCertificate}', '{$commercialActivityNotes}', '{$finalDirectorImage}', '{$boardResolution}'
							   
							   )";
							   
		 if($db->query($insertCandidateQuery)){
        $session->msg("s", "you have registered successfully... \r\n you can now get notifications on our vacancies... your account is ready for login\r\n default password is business username is all small caps");
        redirect('register_candidate.php',false);
      } 
	  else {

        $session->msg("d", "Sorry failed to register... try again later with all the details included as NBM demands it");
        redirect('register_candidate.php',false);
      }
							   
							   
							   
	
  }
  
   else 
  {
	  $session->msg("d", $errors);
     redirect('register_candidate.php',false);
  }
  }
  
 

  
?>

    <?php
	include('header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12" style = "background:url('images/bg_body.jpg')"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
     
        <div class="row">
		<!-- start with table of users -->
		
				
		<!-- basic business info to the left--->
          <div class="col-md-6 employeeform" style = "background-color:lightgreen">
            <p id="message"></p>
			
	<form method = "post" action = "register_candidate.php" enctype="multipart/form-data">
          
             <table class="table table-striped">
		
		<tr>
		<th colspan = '2' class = "text-center" style ="background-color:blue"><label>Basic Business Information</th>
		</tr>
		
		<tr>
             <th> <input type="text" name="businessName" class="form-control" placeholder="Business Name" required></th>
			<td><input type="text" name="businessUserName" class="form-control" placeholder="Business UserName" required></td>
		</tr>
		
		<tr>
		<td>
			 <select class="form-control" name="businessType">
				<option value = "">Business Type </option>
                   <option value="PROP">Sole Proprietorship</option>
				    <option value="PART">Partnership</option>
					 <option value="LTD">Limited Entity</option>
              </select>
			</td>
						<th><input type="email" name="businessEmailAddress" class="form-control" placeholder="Business Email" required></th>

			
		</tr>
		<tr>
					<th><input type="text" name="businessPassword" onfocus="this.type='password'" class="form-control" placeholder="Business Password" required></th>

			<td><input type="phone" name="businessPhoneNumber" class="form-control" placeholder="Business Phone Number" required></td>
		</tr>
		<tr>
			<th><input type="text" name="businessPostalAddress" class="form-control" placeholder="Business Postal Address" required></th>
			<th>
			
			 <select class="form-control" name="businessDistrict" required = "required">
				<option value = "">Business District</option>
                  <?php foreach ($all_districts as $a_district ):
				  ?>
                   <option value="<?php echo $a_district['id'];?>"><?php echo ucwords($a_district['name']);?></option>
                <?php endforeach;?>
                </select>
			
			</th>
		
		</tr>
		<tr>
		<td><input type="text" name="businessLocation" class="form-control" placeholder="Business Location" required></td>

		<th><input type="text" name="dailyCustomers" onfocus="this.type='number'" class="form-control" placeholder="Daily Customers" required></th>

		</tr>
		<tr>
		
		<td><input type="text" name="dailySales" onfocus = "this.type='number'" class="form-control" placeholder="dailySales" required></td>

		<th><input type="text" name="businessPremisesImage" onfocus="this.type='file'" class="form-control" placeholder="Upload Premises Image" required></th>

		</tr>
		<tr>
		<td><input type="text" name="businessPermitImage" onfocus = "this.type = 'file'" class="form-control" placeholder="Upload TPIN" title = "Upload business permit certificate for at least past 18 months" data-toggle = "tooltip" data-placement = "bottom"  required></td>

		<td><input type="text" name="tpin" onfocus = "this.type = 'file'" class="form-control" placeholder="Upload TPIN" title = "Upload TPIN (Taxpayer Identification Number) given by MRA to prove you pay tax" data-toggle = "tooltip" data-placement = "bottom"  required></td>

		</tr>
			
			
		
		<tr>
		<th colspan = '2' class = "text-center" style = "background-color:yellow;"><label>For Limited Companies</th>
		</tr>
		<tr>
			<th><input type="text" name="incorporationCertificate" onfocus = "this.type='file'"class="form-control" placeholder="Ipload Incorporation Certficate"></th>
			<td><input type="text" name="commercialActivityNotes" class="form-control" placeholder = "18 mon. commercial activity notes" title="Commercial Activity Notes for last 18 months" data-toggle = "tooltip" data-placement = "bottom"></td>
		</tr>
		<tr>
			<th><select class="form-control" name="boardResolution" title = "Select Board of Directors' Consent to Participate in Agent Banking" data-toggle = "tooltip" data-placement="top">
				<option value = "">Board of Directors Resolution </option>
                   <option value="1">Board Accepted</option>
				    <option value="0">Board Rejected</option>
              </select></th>
			<td><input type="text" name="directorImage" onfocus = "this.type = 'file'" class="form-control" placeholder="Upload Director ID Image"></td>
		</tr>
		
		
		
			
	</table>
           
          </div>
<!--employee information -->
    <div class="col-md-6 employeeform" style = "background-color:skyblue">
  
 
             <table class="table table-striped">
	    <tr>
		<th colspan = '2' class = "text-center" style = "background-color:green"><label>Employee Information</th>
		</tr>
		 <tr>
		<th colspan = '2' class = "text-center" style = "background-color:blue;"><label>1. Manager</th>
		</tr>
		
		
		
	<tr>
			<th><input type="text" name="managerName" class="form-control" placeholder="Full Name" required></th>
			<td><input type="phone" name="managerPassportPhoto" class="form-control" onfocus = "this.type = 'file'" placeholder="Upload Passport size photo" required></td>
		</tr>
		<tr>
			<th><input type="text" name="managerCertificate"  onfocus = "this.type = 'file'" class="form-control" placeholder="Upload Highest Academic Certificate" required></th>
			<td><input type ="text" class="form-control" name="managerCV" onfocus = "this.type = 'file'" placeholder = "Upload CV" required = "required"></td>
		</tr>
		<tr>
		<th colspan = '2' class = "text-center" style = "background-color:blue"><label>2. First Assistant</th>
		</tr>
		<tr>
			<th><input type="text" name="assistant1Name" class="form-control" placeholder="Full Name" required></th>
			<td><input type="phone" name="assistant1PassportPhoto" class="form-control" onfocus = "this.type = 'file'" placeholder="Upload Passport size photo" required></td>
		</tr>
		<tr>
			<th><input type="text" name="assistant1Certificate"  onfocus = "this.type = 'file'" class="form-control" placeholder="Upload Highest Academic Certificate" required></th>
			<td><input type ="text" class="form-control" name="assistant1CV" onfocus = "this.type = 'file'" placeholder = "Upload CV" required = "required"></td>
		</tr>
		<tr>
		<th colspan = '2' class = "text-center" style = "background-color:blue"><label>3. Second Assistant</th>
		</tr>
		<tr>
			<th><input type="text" name="assistant2Name" class="form-control" placeholder="Name" required></th>
			<td><input type="phone" name="assistant2PassportPhoto" class="form-control" onfocus = "this.type = 'file'" placeholder="Upload Passport size photo" required></td>
		</tr>
		<tr>
			<th><input type="text" name="assistant2Certificate"  onfocus = "this.type = 'file'" class="form-control" placeholder="Upload Highest Academic Certificate" required></th>
			<td><input type ="text" class="form-control" name="assistant2CV" onfocus = "this.type = 'file'" placeholder = "Upload CV" required = "required"></td>
		</tr>
		

	</table>
							<button type="submit" name = "submit_candidate"class="btn btn-block btn-warning pull-right insertButton">Register</button>


            </form>

          </div>

         
		  </div>
		  <!--employee information end -->
		  
        </div>
      </div>
	  </div>
	  </div>

    </div><!-- /.container -->
<!--scripts were here -->
  </body>
  <script>
  
	 $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
	 });
  
  
  </script>
  
</html>
