 <?php 
 include ('includes/load.php'); 
 $user = current_user();
 $id = $_GET['eid'];
 //in order to get information for both the jobs and candidates depending on the contents of their association table [applies_for] 
 //first ly we get the information from the joint table
 $applies_for_info = find_by_job_id($id);
 
 //then with the jobId and candidate id returned from there, we split them
 
 $job_info = find_by_id ('jobs', $id); //use the id of the job returned from the last page to get job information... this can as well be achieved by using the jobId from the returned
 //applies for table
 

 $applies_for_candidate_id = $applies_for_info['candidateId']; //get the candidate id from applies_for
 $candidate_info = find_by_id ('users', $applies_for_candidate_id); // get information of the candidate using that id
 
 /** function that returns all the info about an applicant to a particular job
 this will be used to sieve out information needed by a particular department  ...this example is for wholesale banking department which looks at the banks transactions and amount the candidate has in their account **/
 $all_applicants = find_all_applicants ($id); 
 $rank_active = rank_active($id);

 
 
 
?>	 
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href = "../vendor/fontawesome/css/fontawesome.css" rel = "stylesheet">

<b style = "color:green; text-weight:bolder">Applicants for <?php echo $job_info['title'];?> Job <?php if($rank_active) :?>
			<button class="btn btn-primary  pull-right"><a href = "rank_candidates.php?id=<?php echo $job_info['id']; ?>" style = "text-decoration:none; color:white !important">Rank Candidates</a></button> <?php endif; ?></b>
			<button class="btn btn-primary  pull-right"><a href = "view_approved.php?id=<?php echo $job_info['id']; ?>" style = "text-decoration:none; color:white !important">View Approved</a></button>
                
 <table class="table table-striped">	
 
 <thead>
                    <tr>
					  <th>#</th>
					  <th class = "text-center">Name</th>
					   	<th class = "text-center">Applied On</th>	   			
				        <th class = "text-center">Aptitude Score</th>
						<th class = "text-center">Actions</th>

                    </tr>
                  </thead>
                  <tfoot>
				   <tr>
					  <th>#</th>
					  <th class = "text-center">Name</th>
					   	<th class = "text-center">Applied On</th>
				        <th class = "text-center">Aptitude Score</th>
						
				        <th class = "text-center">Actions</th>
                    </tr>
                    
                  </tfoot>

                  <tbody>
				<?php foreach($all_applicants as $a_candidate): 
				$candidateCorrect = calculateCorrectAnswers ($job_info['id'], $a_candidate['id']);
				$correctAnswers = $candidateCorrect['totalCorrect'];
				$totalQuestions = countAptitudeQuestions ($job_info['id']);
				$questionCount = $totalQuestions['totalQuestions'];
				
				?>
				
          <tr>
           <td class="text-center"><?php echo count_id();?></td>
		    <td class="text-center"><?php echo remove_junk(ucwords($a_candidate['first_name']. ' '.$a_candidate['last_name']))?></td>
      
		     <td class="text-left"><?php echo read_date($a_candidate['dateApplied'])?></td>
			 <td class="text-left"><?php echo $correctAnswers . '/'.$questionCount; ?></td>


		 
           <td class="text-left">
             <div class="btn-group">
			  <div class='btn btn-info btn-xs info-button' xid='<?php echo $a_candidate['id']?>' jid ='<?php echo $a_candidate['jobId']?>' uid = '<?php echo $user['id']?>'><i class = 'fa fa-info' title = "info & create new"data-toggle = "tooltip" data-placement="bottom"></i></div>
                <a href="edit_job.php?id=<?php echo (int)$a_candidate['id'];?>" class="btn btn-xs btn-success" data-toggle="tooltip" title="Approve">
                  <i class="fa fa-thumbs-up"></i>
               </a>
			    <a href="edit_job.php?id=<?php echo (int)$a_candidate['id'];?>" class="btn btn-xs btn-warning" data-toggle="tooltip" title="Disapprove">
                  <i class="fa fa-thumbs-down"></i>
               </a>
			    <a href="edit_job.php?id=<?php echo (int)$a_candidate['id'];?>" class="btn btn-xs btn-primary" data-toggle="tooltip" title="Send internal message on this job & applicant">
                  <i class="fa fa-comments"></i>
               </a>
                
                </div>
           </td>
          </tr>
        <?php endforeach;?>
       </tbody>
	    <script>  
	   $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});
</script>

 <script> 
      $(document).ready(function(){

        $(document).on('click', '.view-button', function(){ 
          $('.employeeform').css("display","block");
          $('.viewemployee').css("display","none");
          var eid = $(this).attr("did"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "job_applicants.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.employeeform').html(res);
            }
          })
         
		 
        });
		
		
		  //View Employee
        $(document).on('click', '.info-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("xid"); 
		  var jid = $(this).attr("jid");
		  var uid = $(this).attr("uid");
          var Data = {'eid':eid, 'jid':jid, 'uid':uid};
          $.ajax({
            url: "candidate_info.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		

		 function deleteUser(x){
           sweetAlert({   title: "Proceed to delete user?!",
                                text: "user account will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_user.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } 
										  
					});
		
		 

		 }
		
		
		


      });
    </script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	
		
 </table>
            </form>