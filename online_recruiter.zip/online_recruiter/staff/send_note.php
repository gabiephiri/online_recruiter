<?php 
require_once ('includes/load.php');
$page_title = 'Send Note';
 $all_ug = find_all('user_groups');
 $all_dept = find_all('departments');
 $all_users = find_all_user();
 $user = current_user ();
 ?>

 <?php
 if(isset($_POST['send_note'])){
   $req_field = array('subject', 'message', 'recepient', 'sender');
   validate_fields($req_field);
   $subject = remove_junk($db->escape($_POST['subject']));
   $message = remove_junk($db->escape($_POST['message']));
   $recepient = remove_junk($db->escape($_POST['recepient']));
      $sender= remove_junk($db->escape($_POST['sender']));


   

   //create default password as a hash of first letter of lastname and full firstname
   
 
   //end password creation 
   
   if(empty($errors)){
      $sql  = "INSERT INTO short_messages(subject, message, recepient, sender)";
      $sql .= " VALUES ('{$subject}', '{$message}', '{$recepient}', '{$sender}')";
      if($db->query($sql)){
		  insert_act('short message', 'sent', '1');
        $session->msg("s", "short message sent successfully");
        redirect('notifications.php',false);
      } else {
		  		  insert_act('message', 'sent', '0');

        $session->msg("d", "Sorry failed to send short message.");
        redirect('notifications.php',false);
      }
   } else {
     $session->msg("d", $errors);
     redirect('notifications.php',false);
   }
 }
?>
<?php include ('recunit_header.php'); ?>


 <div class="container">
		     <?php echo display_msg($msg); ?>
 
      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">NBMORE Staff</a>
            </li>
            <li class="breadcrumb-item active">Send Message</li>
			
			</ol>

		  <!--start create user category -->
 <div class="card mb-3"  id = "add_uc">
        <div class="card-header"><i class = "fa fa-comments"></i> <i class = "fa fa-user"></i>  <span>Send a short message </span></div>
        <div class="card-body">
          <form method = "post" action = "send_note.php">
            <div class="form-group">
              <div class="form-row">
               
				<div class="col-md-4">
                  <div class="form-group">
                    <input type="text"  class="form-control" placeholder="subject" name = "subject" required="required" >
                  </div>
                </div>
				<div class="col-md-4">
                  <div class="form-group">
                    <input type="text"  class="form-control" placeholder="Message" name = "message" required="required" >
                  </div>
                </div>
				
				
				<div class = "col-md-4">
                <select class="form-control" name="recepient" required = "required">
				<option value = "">Select Recepient </option>
                  <?php foreach ($all_users as $a_user ):
				      if ($a_user['id']!=$user['id']):
				  ?>
                   <option value="<?php echo $a_user['id'];?>"><?php echo ucwords($a_user['first_name']. ' '.$a_user['last_name']);?></option>
				   <?php endif; ?>
                <?php endforeach;?>
                </select>
				</div>
				
                <div class="col-md-4">
                  <div class="form-label-group">
                            <button  name="send_note" class="btn btn-primary pull-right"> Send Message</button>
                    </div>
                </div>
				                    <input type="text"  style = "display:none" class="form-control" value = "<?php echo $user['id']?>" name = "sender" required="required" >

              </div>

            </div>

           
           
          </form>
         
        </div>
   
    </div>
	</div>
	</div>
	
	
		  
		  
		  <!-- end add user category -->
		  
		  

        </div>
        <!-- /.container-fluid -->

       

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
  
