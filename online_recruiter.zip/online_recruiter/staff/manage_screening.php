<?php 
require_once ('includes/load.php');
$page_title = 'Manage Screening';
 page_require_level(3);
 $id = $_GET['id'];
$all_questions = find_screening_questions($id);
 $job_info = find_by_id('jobs', $id);
 
 if (!$job_info)
 {
	 $session->msg('d', "Choose a job to edit first");
	 redirect ('manage_jobs', false);
 }
 
 ?>

 <?php
 if(isset($_POST['submit_question'])){
   $jobId = (int)remove_junk($db->escape($_POST['jobId']));
   $question = $_POST['question'];
   $a= remove_junk($db->escape($_POST['a']));
   $b = remove_junk($db->escape($_POST['b']));
    $c= remove_junk($db->escape($_POST['c']));
   $d= remove_junk($db->escape($_POST['d']));
   $answer = remove_junk($db->escape($_POST['answer']));
   
   
   

      $sql  = "INSERT INTO screening_questions (jobId, question, a , b , c , d, answer)";
	  $sql .= "VALUES ('{$jobId}', '{$question}', '{$a}', '{$b}', '{$c}', '{$d}', '{$answer}' )";
	  
      if($db->query($sql)){
		  insert_act('screening question', 'added', '1');
        $session->msg("s", "Successfully added screening question");
        redirect('screening_questions.php?id='.$job_info['id'],false);
      } else {
		insert_act('screening question', 'added', '0');
        $session->msg("d", "Sorry failed to add screening question.");
        redirect('screening_questions.php?id='.$job_info['id'],false);
      }
   } 
 
?>
<?php include ('hr_header.php'); ?>


 <div class="container">
 		     <?php echo display_msg($msg); ?>

 
      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">HR</a>
            </li>
            <li class="breadcrumb-item active">Manage Jobs</li>
			<li class="breadcrumb-item pull-right">
              <a href="breadcrumb-item active">Manage Screening</a>
            </li>
			</ol>


		  <!--start create user category -->
 <div class="card mb-3"  id = "add_uc">

        <div class="card-header"><i class = "fa fa-plus"></i> <i class = "fa fa-tasks"></i>  <span>Add Question for <strong><?php echo $job_info['title']?>  Job</strong> </span></div>
        <div class="card-body">
          <form method = "post" action = "manage_screening.php?id=<?php echo $job_info['id']; ?>">
		  <div class = "form-row">
		  <div class = "col-md-12">
		  <?php echo display_msg($msg); ?>
		  </div>
		  </div>
            <div class="form-group">
              <div class="form-row">
			  <div class="col-md-3">
                  <div class="form-group">
                    <label  for = "jobDescription"> Question </label>
                  </div>
                </div>	
               
				<div class="col-md-12">
                  <div class="form-group">
                    <textarea type="text"  class="form-control" placeholder="Type multiple choice question" name = "question" required="required"  autocomplete></textarea>
                  </div>
                </div>
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "a"> A</label>
                  </div>
                </div>
				<div class="col-md-9">
                  <div class="form-group">
                    <input type="text"  class="form-control" placeholder="" name = "a" required="required"  autocomplete>
                  </div>
                </div>
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "b"> B</label>
                  </div>
                </div>
				<div class="col-md-9">
                  <div class="form-group">
                    <input type="text"  class="form-control" placeholder="" name = "b" required="required"  autocomplete>
                  </div>
                </div>
				
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "c"> C</label>
                  </div>
                </div>
				<div class="col-md-9">
                  <div class="form-group">
                    <input type="text"  class="form-control" placeholder="" name = "c" required="required"  autocomplete>
                  </div>
                </div>
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "d"> D</label>
                  </div>
                </div>
				<div class="col-md-9">
                  <div class="form-group">
                    <input type="text"  class="form-control" placeholder="" name = "d" required="required"  autocomplete>
                  </div>
                </div>
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "answer"> Answer</label>
                  </div>
                </div>
				
				<div class="col-md-3">
                  <div class="form-group">
			  <select class="form-control" name="answer" required = "required">
				<option value = "">Select Correct Answer</option>
				<option value = "A"> A </option>
				<option value = "B"> B </option>
				<option value = "C"> C </option>
				<option value = "D"> D </option> 
                </select>
			   </div>
                </div>
				
                  <div class="form-group">
                            <button  name="submit_question" class="btn btn-primary pull-right"> Submit Question</button>
                    </div>
                </div>
				</div>
				<div class="col-md-3" style = "display:none;">
                  <div class="form-group">
                    <input type="number"  class="form-control"  value = "<?php echo $job_info['id']?>" name = "jobId" required="required">
                  </div>
                </div>
              </div>

            </div>

           
           
          </form>
         
        </div>
   
    </div>
	</div>
	</div>
    </div>
   </div>
    </div>
