<?php require_once('includes/load.php');
$page_title = 'Jobs';
 $id = $_GET['id'];
 $applies_for_info = find_by_job_id($id);
 
 //then with the jobId and candidate id returned from there, we split them
 
 $job_info = find_by_id ('jobs', $id); //use the id of the job returned from the last page to get job information... this can as well be achieved by using the jobId from the returned
 //applies for table
 

 $applies_for_candidate_id = $applies_for_info['candidateId']; //get the candidate id from applies_for
 $candidate_info = find_by_id ('users', $applies_for_candidate_id); // get information of the candidate using that id
 
 /** function that returns all the info about an applicant to a particular job
 this will be used to sieve out information needed by a particular department  ...this example is for wholesale banking department which looks at the banks transactions and amount the candidate has in their account **/
 $all_applicants = find_all_applicants ($id); 
 
 ?>
  


 <!--handle multi-select and insert into a quotations table -->
  <?php
  $selector = "SELECT * FROM applies_for WHERE jobId = '{$id}' AND cardsDecision = '1' ORDER BY id ASC";
  $execute = $db ->query ($selector);
  
  $rowCount = mysqli_num_rows($execute);
  if (isset($_POST['submit_ranks']) && isset($_POST['count'])){	  
  	$insertItemsSucess = null;

	  for ($i =0; $i < $rowCount; $i++)
	  {
              $jobId = $_POST['job_id'];
			  $rankNumber= $_POST['rank_number'][$i];
			  $candidateId = $_POST['candidate_id'][$i];
			  
			  
			  $answeredQuestionInsertQuery  = "UPDATE applies_for SET candidateRank = '{$rankNumber}'";
			  $answeredQuestionInsertQuery .= " WHERE jobId = '{$jobId}' AND candidateId = '{$candidateId}' LIMIT 1";
			 $insertItemsSucess =   $db->query($answeredQuestionInsertQuery); 
			 
			
	}
  
 if ($insertItemsSucess)
		{
			$session->msg ("s", "candidates ranked successfully");
			redirect('rank_candidates.php?id='.$job_info['id'], false);
		}	
	else 
			{
				$session->msg ("d", "failed to rank candidates... try again later or contact the system administrator!");
				redirect('rank_candidates.php?id='.$job_info['id'], false);
			}
			 
	  } 

		
  
  
  ?>
<?php include ('hr_header.php'); ?>


      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Admin</a>
            </li>
			
			<li class="breadcrumb-item">
              <a href="view_rank.php?jid=<?php echo $job_info['id'];?>">View Rank</a>
            </li>
            <li class="breadcrumb-item active">Rank Candidates</li>
             
			
          </ol>
		  
		  <div class = "col-md-12">
<?php echo display_msg($msg); ?>
</div>



        

          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-head0er">
             
              <h3> <i class="fas fa-users"></i> <?php echo ucwords($job_info['title']. ' Ranking') ?></h3><u>Note:</u> The candidates are not sorted in any order</div>
            <div class="card-body">
			<form method = "post" action = "rank_candidates.php?id=<?php echo $job_info['id']?>">
              <div class="table-responsive">
                <table class="table table-striped" id="dataTable" width="100%" cellspacing="0">


                  <tbody>
				  <tr style = "display:none;"> <td><input type = "number" name = "job_id" value = "<?php echo $job_info['id']?>"></td><tr>
				  <?php
				  $i = 1;
				 foreach($all_applicants as $a_candidate): 
				  
				  $candidate_inf = find_by_id ('candidates', $a_candidate['candidateId']);
				  $full_name = $candidate_inf['first_name']. ' '. $candidate_inf['other_names']. ' '.$candidate_inf['last_name'];
				 ?>
          <tr>
		   

           <td class="text-left"><b>
		   <input name = "rank_number[]" size = "1" cols = "1" type = "number" value = "<?php echo $i++; ?>"required = "required">
		 
		   </select>



		   </b> . <?php echo ucwords($full_name)?> 
           
           	<input name="candidate_id[]" style = "display:none;"type = "number"  value="<?php echo $candidate_inf['id'];?>" />

			<input type = "number" style = "display:none;" name = "count"value = "<?php echo $i++ ?>">

           
               
           </td>
          </tr>
        <?php endforeach;?>
		<tr><td><button class = "btn btn-warning pull-right" name = "submit_ranks">Submit Rank</button></td></tr>
       </tbody>
	 <script>  
	   $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});
</script>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

       

      </div>
      <!-- /.content-wrapper -->

    </div>


    <!-- Scroll to Top Button-->
  
