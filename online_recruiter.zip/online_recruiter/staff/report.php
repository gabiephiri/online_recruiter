<?
include_once('includes/load.php');
  $page_title = 'HR Summary Information';
 $count_messages = count_by_id('messages');
 $message_count = $count_messages['total'];
 $count_jobs = count_by_id('jobs');
 $job_count = $count_jobs['total'];
 $active_jobs = count_active_jobs();
 $all_active_jobs = find_all_jobs();

?>

<?php include ('hr_header.php'); ?>

      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li>
              <a href="#"><h2><i class = " fa fa-chart-pie"> </i></a>
            </li>
            <li>  &nbsp; &nbsp;  Online Recruitment Summary Information </li> </h3>
          </ol>
		  
		  <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#"><b style = "color:red"> Jobs</b></a>
            </li>
            <li class="breadcrumb-item active"><a href = "active_jobs.php"> Active <b style = "color:red">[<?php echo $active_jobs; ?>]</b></a></li>
			<li class="breadcrumb-item active"><a href = "active_jobs.php"> Finished / Deactivated <b style = "color:red">[<?php echo $job_count-$active_jobs; ?>]</b></a></li>
			
			<li class="breadcrumb-item active"><a href = "jobs.php"> All Jobs <b style = "color:red">[<?php echo $job_count; ?>]</b></a></li>
			<li class="breadcrumb-item active" style = "color:black !important"><a href = "#" style = "text-decoration:none !important; color:black!important"> Latest Job : 
			<?php 
			$queryLatestJob = "SELECT * FROM jobs order BY dateAdded DESC LIMIT 1";
			$executeLatest = $db->query ($queryLatestJob);
			$row = mysqli_fetch_assoc($executeLatest);
			$dateAdded = $row['dateAdded'];
			$job_title = $row ['title'];
			?>
			<?php echo $job_title ?> Posted On <?php echo read_date ($dateAdded); ?>
			</a></li>

			
          </ol>
           
		   
		    
          <!-- Icon Cards-->
          <div class="row">
           
			
			 <ol class="breadcrumb">
			 
            <li class="breadcrumb-item">
              <a href="#"><b style = "color:red"> Latest Jobs</b></a>
            </li>
			 <?php 
				  $latest_jobs = find_all_limited ('jobs', 3);
				  foreach ($latest_jobs as $latest_job):
				  $job_title = $latest_job['title'];
				  $agents = $latest_job['agentCount'];
				  $days_to_expiry = count_days_to_expiry ($latest_job['id']);
				  
				  ?>
            <a href = "active_jobs.php"> &nbsp; &nbsp;<?php echo $job_title; ?>... {<?php echo $agents?>} Agents Needed &nbsp; &nbsp;  </b></a>
			 <b>
			<?php if ($days_to_expiry > 0) {
			echo "Expiring in ". $days_to_expiry. ' days '; 
			}
			else 
			{
			echo "Expired ". abs($days_to_expiry) . ' days ago ';
			}
			?>
			</li>
			<?php endforeach; ?> 
              </b>
			
          </ol>
		  
		  <ol class="breadcrumb">
			 
            <li class="breadcrumb-item">
              <a href="#"><b style = "color:red"> Applicants</b></a>
            </li>
			 <?php
	                     $all_active_jobs = find_all_jobs();
	                   foreach ($all_active_jobs  as $a_job): 
	                   $allApplicants = countApplicants($a_job['id']);
	  
	                  ?>
            <li class="breadcrumb-item active"><a href = "active_jobs.php"><?php echo $a_job['title']; ?> <b style = "color:green"><?php echo $allApplicants['totalApplicants']?> </b>Candidates Applied</a></li>
			<?php endforeach; ?>
			
			

			
          </ol>
		  
		  
		  <!--employed guys -->
		 
         <ol class="breadcrumb">
			 
            <li class="breadcrumb-item">
              <a href="#"><b style = "color:red"> Agents Employed</b></a>
            </li>
			 <?php
	                     $all_active_jobs = find_all_jobs();
	                   foreach ($all_active_jobs  as $a_job):  
					      $jobId = $a_job['id'];
						  $agentsNeeded = $a_job['agentCount'];
						  ?>
					            <li class="breadcrumb-item active"><a href = "#"><?php echo $a_job['title']; ?> <b style = "color:darkblue">[out of <?php echo $agentsNeeded?> agents needed]</b> </a>&nbsp;
   
					
                      <?php 					
	                   $allEmployed = find_employed ($jobId);
					   
					   foreach ($allEmployed as $an_agent) :
					   $agentId = $an_agent ['candidateId'];
					   $agent_info = find_by_id('candidates', $agentId);
					   $agent_name = $agent_info['name'];
	  
	                  ?>
            <a href = "#">&nbsp;<b style = "color:green; font-weight:bolder;"> <?php echo $agent_name; ?>... </b></a></li>  
			<?php endforeach; ?>
			<><>
			<?php endforeach; ?>
			
			

			
          </ol>
		  
		  
		  <ol class="breadcrumb">
			 
            <li class="breadcrumb-item">
              <a href="#"><b style = "color:red"> Unprocessed Candidates</b></a>
            </li>
			 <?php
			              $all_jobs = find_all_jobs ();
	                   foreach ($all_jobs as $a_job): 
                           $jobId = $a_job['id'];	
						  $job_title = $a_job['title'];
						  ?>
					            <li class="breadcrumb-item active"><a href = "#"><?php echo $job_title; ?> </a>&nbsp;
   
					
                      <?php 					
	                     $unprocessed = find_unprocessed_applicants($jobId);
					   
					   foreach ($unprocessed as $an_agent) :
					   $agentId = $an_agent ['candidateId'];
					   $agent_info = find_by_id('candidates', $agentId);
					   $agent_name = $agent_info['name'];
	  
	                  ?>
            <a href = "#">&nbsp;<b style = "color:green; font-weight:bolder;"> <?php echo $agent_name; ?>... </b></a></li>  
			<?php endforeach; ?>
			<><>
			<?php endforeach; ?>
			
			

			
          </ol>
		  
		  
		  <ol class="breadcrumb">
			 
            <li class="breadcrumb-item">
              <a href="#"><b style = "color:red"> Candidates Approved by Cards &amp eBanking Division</b></a>
            </li>
			 <?php
			              $all_jobs = find_all_jobs ();
	                   foreach ($all_jobs as $a_job): 
                           $jobId = $a_job['id'];	
						  $job_title = $a_job['title'];
						  ?>
					            <li class="breadcrumb-item active"><a href = "#"><?php echo $job_title; ?> </a>&nbsp;
   
					
                      <?php 					
	                     $unprocessed = find_cards_approved_applicants($jobId);
					   
					   foreach ($unprocessed as $an_agent) :
					   $agentId = $an_agent ['candidateId'];
					   $agent_info = find_by_id('candidates', $agentId);
					   $agent_name = $agent_info['name'];
	  
	                  ?>
            <a href = "#">&nbsp;<b style = "color:green; font-weight:bolder;"> <?php echo $agent_name; ?>... </b></a></li>  
			<?php endforeach; ?>
			<><>
			<?php endforeach; ?>
			
			

			
          </ol>
		  
		    <ol class="breadcrumb">
			 
            <li class="breadcrumb-item">
              <a href="#"><b style = "color:red"> Job Screening Questions</b></a>
            </li>
			 <?php
			              $all_jobs = find_all_jobs ();
	                   foreach ($all_jobs as $a_job): 
                           $jobId = $a_job['id'];	
						  $job_title = $a_job['title'];
						  $aptitudeQuestionsCount = countAptitudeQuestions ($jobId);
						  ?>
					            <li class="breadcrumb-item active"><a href = "#"><?php echo $job_title; ?> </a>&nbsp;
   
				
            <a href = "#">&nbsp;<b style = "color:green; font-weight:bolder;"> [<?php echo $aptitudeQuestionsCount['totalQuestions']; ?>]... </b></a></li>  
			<?php endforeach; ?>
			<><>
			
			

			
          </ol>
		  
		  
					 
		  
		  
		  
		  
		  <!--end employed guys -->
			
			
			<!-- start --->
				
          </div>

        

        </div>
     

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
  
