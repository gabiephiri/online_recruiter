 
<?php include("includes/load.php");
$page_title = 'Applicants by Job';

$all_active_jobs = find_all_jobs();

 ?>
 
    <?php
	
	$user = current_user ();
	if ($user['user_level'] === '3'){
	include('recunit_header.php');
	}
	else if ($user['user_level'] ==='2')
	{
	 	include('hr_header.php');

	}
	?>
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header">
       <ol class="breadcrumb">
       <?php
	  
	  foreach ($all_active_jobs  as $a_job): 
	  $allApplicants = countApplicants($a_job['id']);
	  
	  ?>

		<tr class='prev' id="pre<?php echo $a_job['id']?>">
		
      <button class='view-button' did='<?php echo $a_job['id']?>'>
	 <span class = "badge badge-primary"> <?php echo $a_job['title']?> 
	 <sup class = "badge badge-danger"><?php echo $allApplicants['totalApplicants']; ?></sup>

	<?php endforeach; ?>

			

          </ol>
		</div>
        <div class="row">

          <div class="col-md-7 employeeform" style = "display:none;"></div>
		   <div class="col-md-12 viewemployee" style = "display:none;"></div>

         
		  </div>
		  
        </div>
      </div>
	  </div>
	  </div>

    </div><!-- /.container -->
 
          

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   <script> 
      $(document).ready(function(){

        $(document).on('click', '.view-button', function(){ 
          $('.employeeform').css("display","block");
          $('.viewemployee').css("display","none");
          var eid = $(this).attr("did"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "job_applicants.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.employeeform').html(res);
            }
          })
         
		 
        });
		
		
		  //View Employee
        $(document).on('click', '.info-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("xid"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "candidate_info.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		

		 function deleteUser(x){
           sweetAlert({   title: "Proceed to delete user?!",
                                text: "user account will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_user.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } 
										  
					});
		
		 

		 }
		
		
		



		
	
	 $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
	 });


      });
    </script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	
	

  </body>
  
</html>
