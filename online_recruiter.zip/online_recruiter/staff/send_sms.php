<?php
include_once("ViaNettSMS.php");

if (isset($_POST['send_sms'])):

// Declare variables.
$Username = "gabiephiri@gmail.com";
$Password = "wylwd";
$MsgSender = "0881120438";
$DestinationAddress = "0996287912";
$Message = "Hello there... this is a message from NBMORE";

// Create ViaNettSMS object with params $Username and $Password
$ViaNettSMS = new ViaNettSMS($Username, $Password);
try
{
	// Send SMS through the HTTP API
	$Result = $ViaNettSMS->SendSMS($MsgSender, $DestinationAddress, $Message);
	// Check result object returned and give response to end user according to success or not.
	if ($Result->Success == true)
		$Message = "Message successfully sent!";
	else
		$Message = "Error occured while sending SMS<br />Errorcode: " . $Result->ErrorCode . "<br />Errormessage: " . $Result->ErrorMessage;
}
catch (Exception $e)
{
	//Error occured while connecting to server.
	$Message = $e->getMessage();
}



?>

<html> 
    <head> 
        <title>ViaNettSMS Example</title> 
    </head> 
    <body> 
<?php 
echo "          <p><strong>SMS Result</strong><br />Status: $Message</p>"; 
?> 
<?php endif; ?>
    </body> 
	
	<form action = "send_sms.php" method = "post">
	<button name = "send_sms" type = "submit" style = "width:200px; height: 40px; background-color:green"> Send SMS </button>
	
	</form>
</html> 
