<?php 
require_once ('includes/load.php');
$page_title = 'Manage Screening';
 $id = $_GET['qid'];
 $question_info = find_by_id ('screening_questions', $id);
 $job_info = find_by_id('jobs', $question_info['jobId']);
 
 if (!$question_info)
 {
	 $session->msg('d', "Choose a question to edit first");
	 redirect ('screening_questions.php?id='.$job_info['id'], false);
 }
 
 ?>

 <?php
 if(isset($_POST['update_question'])){
   $jobId = (int)remove_junk($db->escape($_POST['jobId']));
   $question_id = $_POST['question_id'];
   $question = $_POST['question'];
   $a= remove_junk($db->escape($_POST['a']));
   $b = remove_junk($db->escape($_POST['b']));
    $c= remove_junk($db->escape($_POST['c']));
   $d= remove_junk($db->escape($_POST['d']));
   $answer = remove_junk($db->escape($_POST['answer']));
   
   
   

      $sql = " UPDATE screening_questions SET question = '{$question}', a = '{$a}', b = '{$b}', c = '{$c}' , d = '{$d}', answer = '{$answer}' WHERE id = '{$question_id}'";
	  
      if($db->query($sql)){
		  insert_act('screening question', 'added', '1');
        $session->msg("s", "Successfully updated  question");
        redirect('edit_question.php?qid='.$question_id,false);
      } else {
		insert_act('screening question', 'added', '0');
        $session->msg("d", "Sorry failed to edit screening question.");
        redirect('edit_question.php?qid='.$question_id,false);
      }
   } 
 
?>
<?php include ('hr_header.php'); ?>


 <div class="container">
 		     <?php echo display_msg($msg); ?>

 
      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">HR</a>
            </li>
            <li class="breadcrumb-item active">Manage Jobs</li>
			<li class="breadcrumb-item active">Manage Screening</li>

			 <li class="breadcrumb-item active">Edit Question</li>

			</ol>


		  <!--start create user category -->
 <div class="card mb-3"  id = "add_uc">

        <div class="card-header"><i class = "fa fa-plus"></i> <i class = "fa fa-question"></i>  <span>Add Question for <strong><?php echo $job_info['title']?>  Job</strong> </span></div>
        <div class="card-body">
          <form method = "post" action = "edit_question.php?qid=<?php echo $question_info['id']; ?>">
		  <div class = "form-row">
		  <div class = "col-md-12">
		  
		  </div>
            <div class="form-group">
              <div class="form-row">
			  <div class="col-md-3">
                  <div class="form-group">
                    <label  for = "jobDescription"> Question </label>
                  </div>
                </div>	
               
				<div class="col-md-12">
                  <div class="form-group">
                    <textarea type="text"  class="form-control" value = "<?php echo $question_info['question']?>" name = "question" required="required"  autocomplete><?php echo $question_info['question']; ?></textarea>
                  </div>
                </div>
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "a"> A</label>
                  </div>
                </div>
				<div class="col-md-9">
                  <div class="form-group">
                    <input type="text"  class="form-control" value = "<?php echo $question_info['a']?>"name = "a" required="required"  autocomplete>
                  </div>
                </div>
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "b"> B</label>
                  </div>
                </div>
				<div class="col-md-9">
                  <div class="form-group">
                    <input type="text"  class="form-control" value = "<?php echo $question_info['b']?>" name = "b" required="required"  autocomplete>
                  </div>
                </div>
				
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "c"> C</label>
                  </div>
                </div>
				<div class="col-md-9">
                  <div class="form-group">
                    <input type="text"  class="form-control" value = "<?php echo $question_info['c']?>" name = "c" required="required"  autocomplete>
                  </div>
                </div>
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "d"> D</label>
                  </div>
                </div>
				<div class="col-md-9">
                  <div class="form-group">
                    <input type="text"  class="form-control" value = "<?php echo $question_info['d']?>" name = "d" required="required"  autocomplete>
                  </div>
                </div>
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "answer"> Answer</label>
                  </div>
                </div>
				
				<div class="col-md-3">
                  <div class="form-group">
			   <select class="form-control" name="answer" required = "required">
				 <option <?php if($question_info['answer'] === 'A') echo 'selected="selected"';?>value="A">A</option>
                  <option <?php if($question_info['answer'] === 'B') echo 'selected="selected"';?> value="B">B</option>
				  <option <?php if($question_info['answer'] === 'C') echo 'selected="selected"';?> value="C">C</option>
				  <option <?php if($question_info['answer'] === 'D') echo 'selected="selected"';?> value="D">D</option>
                </select>
			   </div>
                </div>
				
                  <div class="form-group">
                            <button  name="update_question" class="btn btn-primary pull-right"> Submit Question</button>
                    </div>
                </div>
				</div>
				<div class="col-md-3" style = "display:none;">
                  <div class="form-group">
                    <input type="number"  class="form-control"  value = "<?php echo $job_info['id']?>" name = "jobId" required="required">
					                    <input type="number"  class="form-control"  value = "<?php echo $question_info['id']?>" name = "question_id" required="required">

                  </div>
                </div>
              </div>

            </div>

           
           
          </form>
         
        </div>
   
    </div>
	</div>
	</div>
    </div>
   </div>
    </div>
