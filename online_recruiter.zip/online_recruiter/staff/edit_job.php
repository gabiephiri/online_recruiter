<?php 
require_once ('includes/load.php');
$page_title = 'Edit Job';
 page_require_level(3);
 $all_districts = find_all('districts');
 $id = $_GET['id'];
 $job_info = find_by_id('jobs', $id);
 
 if (!$job_info)
 {
	 $session->msg('d', "Choose a job to edit first");
	 redirect ('manage_jobs', false);
 }
 
 ?>

 <?php
 if(isset($_POST['submit_job'])){
   $jobId = remove_junk($db->escape($_POST['jobId']));
   $title = remove_junk($db->escape($_POST['title']));
   $district = remove_junk($db->escape($_POST['district']));
   $location = remove_junk($db->escape($_POST['location']));
   $jobDescription = remove_junk($db->escape($_POST['jobDescription']));
   $personSpecification = remove_junk($db->escape($_POST['personSpecification']));
   $agentCount = remove_junk($db->escape($_POST['agentCount']));
   $dateAdded = remove_junk ($db->escape($_POST['dateAdded']));
   $deadline = remove_junk($db->escape($_POST['deadline']));
   
   

      $sql  = "UPDATE jobs SET  title = '{$title}', district = '{$district}', jobDescription = '{$jobDescription}', personSpecification = '{$personSpecification}', location = '{$location}', agentCount = '{$agentCount}', dateAdded = '{$dateAdded}', deadline = '{$deadline}' WHERE id = {$jobId}";
	  
      if($db->query($sql)){
		  insert_act('job', 'updated', '1');
        $session->msg("s", "Successfully updated  job");
        redirect('edit_job.php?id='.$job_info['id'],false);
      } else {
		insert_act('job', 'added', '0');
        $session->msg("d", "Sorry failed to create job.");
        redirect('edit_job.php?id='.$job_info['id'],false);
      }
   } 
 
?>
<?php include ('hr_header.php'); ?>


 <div class="container">
		     <?php echo display_msg($msg); ?>
 
      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">HR</a>
            </li>
            <li class="breadcrumb-item active">Manage Jobs</li>
			<li class="breadcrumb-item pull-right">
              <a href="breadcrumb-item active">Add Job</a>
            </li>
			</ol>

		  <!--start create user category -->
 <div class="card mb-3"  id = "add_uc">
        <div class="card-header"><i class = "fa fa-plus"></i> <i class = "fa fa-tasks"></i>  <span>Edit &nbsp; <strong><?php echo $job_info['title']?> </strong> Job</span></div>
        <div class="card-body">
          <form method = "post" action = "edit_job.php?id=<?php echo $job_info['id']; ?>">
            <div class="form-group">
              <div class="form-row">
			  <div class="col-md-3">
                  <div class="form-group">
                    <label  for = "jobDescription"> Job Title </label>
                  </div>
                </div>	
               
				<div class="col-md-3">
                  <div class="form-group">
                    <input type="text"  class="form-control" placeholder="Job Title"value = "<?php echo $job_info['title'] ?>" name = "title" required="required"  autocomplete>
                  </div>
                </div>
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "jobDescription"> District</label>
                  </div>
                </div>
				<div class="col-md-3">
                  <div class="form-group">
				  

			     <select class="form-control" name="district" required = "required">
				<option value = "">Select District</option>
                  <?php foreach ($all_districts as $a_district ):
				  ?>
                   <option <?php if($a_district['id'] === $job_info['district']) echo 'selected="selected"';?> value="<?php echo $a_district['id'];?>"><?php echo ucwords($a_district['name']);?></option>
                <?php endforeach;?>
                </select>
			                  </div>
                </div>
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "jobDescription"> Location</label>
                  </div>
                </div>	
				<div class="col-md-7">
                  <div class="form-group">
                    <input type="text"  class="form-control" placeholder="Location" value = "<?php echo $job_info['location']?>"name = "location" required="required" autocomplete >
                  </div>
                </div>
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "jobDescription"> Job Description </label>
                  </div>
                </div>	
				
				<div class = "col-md-6">
                  <div class="form-group">
                    <button class = "btn btn-primary"  class="form-control" onclick = "insertDefaultJobDescription(); return false;"id = "defaultJobDescription">Insert Default Job Description</button>
                 </div>
				 </div>
				 
				  
         
				<div class="col-md-12">
                  <div class="form-group">
                    <textarea type="text"  class="form-control" value = "<?php echo $job_info['jobDescription']?>" id = "jobDescription" placeholder="Job Description" name = "jobDescription"><?php echo $job_info['jobDescription']?></textarea>
                  </div>
                </div>
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "personSpecification"> Person Specification </label>
                  </div>
                </div>	
				<div class = "col-md-6">
                  <div class="form-group">
                    <button class = "btn btn-primary"  class="form-control" onclick = "insertDefaultPersonSpecification(); return false;"id = "defaultJobDescription">Insert Default Person Specification</button>
                 </div>
				 </div>

                <div class="col-md-12">
                  <div class="form-group">
                    <textarea type="text"  class="form-control" value = "<?php echo $job_info['personSpecification']?>"id = "personSpecification" rows = "5" placeholder="Person Specification" name = "personSpecification"><?php echo $job_info['personSpecification']?></textarea>
                  </div>
                </div>
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "dateAdded"> Date Added </label>
                  </div>
                </div>	

                <div class="col-md-3">
                  <div class="form-group">
                    <input type="text"  class="form-control"  value = "<?php echo $job_info['dateAdded']?>"onfocus = "this.type = 'date'" placeholder="Pick Deadline" name = "dateAdded" required="required" >
                  </div>
                </div>				
				
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "deadline"> Due Date</label>
                  </div>
                </div>	
				
				<div class="col-md-3">
                  <div class="form-group">
                    <input type="text"  class="form-control"  value = "<?php echo $job_info['deadline']?>"onfocus = "this.type = 'date'" placeholder="Pick Deadline" name = "deadline" required="required">
                  </div>
                </div>
				
				<div class="col-md-3">
                  <div class="form-group">
                    <label  for = "agentCount"> Agents Needed</label>
                  </div>
                </div>	
				
				
				<div class="col-md-3">
                  <div class="form-group">
                    <input type="number"  class="form-control"  value = "<?php echo $job_info['agentCount']?>"placeholder="No. of Agents" name = "agentCount" required="required">
                  </div>
                </div>
				<div class = "col-md-12">	
                <div class="col-md-4">
                  <div class="form-group">
                            <button  name="submit_job" class="btn btn-primary pull-right"> Submit Changed Job</button>
                    </div>
                </div>
				</div>
				<div class="col-md-3" style = "display:none;">
                  <div class="form-group">
                    <input type="number"  class="form-control"  value = "<?php echo $job_info['id']?>" name = "jobId" required="required">
                  </div>
                </div>
              </div>

            </div>

           
           
          </form>
         
        </div>
   
    </div>
	</div>
	</div>
    </div>
   </div>
    </div>
<script type = "text/javascript">
function insertDefaultPersonSpecification ()
{
	document.getElementById ('personSpecification').innerHTML = "updated person specification \n";
}

function insertDefaultJobDescription ()
{
	document.getElementById ('jobDescription').innerHTML = "updated job description ";
}


</script>