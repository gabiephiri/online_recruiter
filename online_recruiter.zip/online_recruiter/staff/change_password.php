<?php
	include "includes/load.php";
		$id = $_GET['eid'];	
		$user_info = find_by_id('users', $id);	
		$user_id = $user_info['id'];
		$all_departments = find_all('departments');
		$all_user_groups = find_all('user_groups');	
		
		$page_title = "Edit My Profile";
		
?>
<?php
// Update user password
if(isset($_POST['update_password'])) {
  $req_fields = array('password');
  validate_fields($req_fields);
  if(empty($errors)){
  $user_info = current_user();
           $id = (int)$user_info['id'];
     $password = remove_junk($db->escape($_POST['password']));
     $h_pass   = sha1($password);
          $sql = "UPDATE users SET password='{$h_pass}' WHERE id='{$db->escape($id)}'";
       $result = $db->query($sql);
        if($result && $db->affected_rows() === 1){
			insert_act('password', 'changed', '1');
          $session->msg('s',"User password has been updated ");
          redirect('edit_profile.php?eid='.$id, false);
        } else {
		  insert_act('password', 'changed', '0');
          $session->msg('d',' Sorry failed to updated user password!');
          redirect('edit_profile.php?eid='.$id, false);
        }
  } else {
    $session->msg("d", $errors);
    redirect('change_password.php?eid='.$id,false);
  }
}
?>
<?php include () ?>
<form method = "post" action = "edit_profile.php?id="<?php echo $id; ?>>
	<table class="table table-striped">
	<div class = "col-md-8">
		<tr>
		 <th>Title </th>
		 <td><select class="form-control" name="title">
				 <option <?php if($user_info['title'] === 'Mr') echo 'selected="selected"';?>value="Mr">Mr</option>
                  <option <?php if($user_info['title'] === 'Mrs') echo 'selected="selected"';?> value="Mrs">Mrs</option>
				  <option <?php if($user_info['title'] === 'Ms') echo 'selected="selected"';?> value="Ms">Ms</option>
				  <option <?php if($user_info['title'] === 'Dr') echo 'selected="selected"';?> value="Dr">Dr</option>
				   <option <?php if($user_info['title'] === 'Prof') echo 'selected="selected"';?> value="Prof">Prof</option>
                </select>
			</td>
		 </tr>
		
		</div>
		</table>
		</form>