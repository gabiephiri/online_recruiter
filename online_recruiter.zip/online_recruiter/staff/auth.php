<?php include_once('includes/load.php'); ?>
<?php
$req_fields = array('username','password' );
validate_fields($req_fields);
$username = remove_junk($_POST['username']);
$password = remove_junk($_POST['password']);

if(empty($errors)){
  $user_id = authenticate($username, $password);
  if($user_id){
    //create session with id
     $session->login($user_id);
    //Update Sign in time
     updateLastLogIn($user_id);
	 
	$user = current_user ();
	$user_level = $user ['user_level'];
	
	if ($user_level === '1')
	{
		$session->msg('s', 'Welcome Admin '. $user['username']);
		redirect ('manage_users.php', false);
	}
	
	else if ($user_level === '2')
	{
		$session->msg('s', 'Welcome HR '. $user['username']);
		redirect ('manage_jobs.php', false);
	}
	
	else 
	{
		$session->msg('s', 'Welcome Officer '. $user['username']);
		redirect ('job_rec.php', false);
	}
	


  } 
  else {
    $session->msg("d", "Sorry Username/Password incorrect.");
    redirect('index.php',false);
  }

} else {
   $session->msg("d", $errors);
   redirect('index.php',false);
}

?>
