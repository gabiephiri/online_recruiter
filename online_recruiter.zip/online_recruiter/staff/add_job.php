<?php 
require_once ('includes/load.php');
$page_title = 'Create Job';
 page_require_level(3);
 $all_districts = find_all('districts');
 ?>

 <?php
 if(isset($_POST['submit_job'])){
   $req_field = array('title', 'district', 'jobDescription', 'personSpecification', 'location', 'deadline');
   validate_fields($req_field);
   $title = remove_junk($db->escape($_POST['title']));
   $district = remove_junk($db->escape($_POST['district']));
   $jobDescription = remove_junk($db->escape($_POST['jobDescription']));
   $personSpecification = remove_junk($db->escape($_POST['personSpecification']));
   $location = remove_junk($db->escape($_POST['location']));
   $agentCount = remove_junk($db->escape($_POST['agentCount']));
   $deadline = remove_junk($db->escape($_POST['deadline']));
   
   
   if(empty($errors)){
      $sql  = "INSERT INTO jobs (title, district, jobDescription, personSpecification, location, agentCount, deadline)";
      $sql .= " VALUES ('{$title}', '{$district}', '{$jobDescription}', '{$personSpecification}', '{$location}','{$agentCount}', '{$deadline}')";
      if($db->query($sql)){
		  insert_act('job', 'added', '1');
        $session->msg("s", "Successfully added job");
        redirect('add_job.php',false);
      } else {
		  		  insert_act('job', 'added', '0');

        $session->msg("d", "Sorry failed to create job.");
        redirect('add_job.php',false);
      }
   } else {
     $session->msg("d", $errors);
     redirect('add_job.php',false);
   }
 }
?>
<?php include ('hr_header.php'); ?>


 <div class="container">
		     <?php echo display_msg($msg); ?>
 
      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">HR</a>
            </li>
            <li class="breadcrumb-item active">Manage Jobs</li>
			<li class="breadcrumb-item pull-right">
              <a href="breadcrumb-item active">Add Job</a>
            </li>
			</ol>

		  <!--start create user category -->
 <div class="card mb-3"  id = "add_uc">
        <div class="card-header"><i class = "fa fa-plus"></i> <i class = "fa fa-tasks"></i>  <span>Create a New Job</span></div>
        <div class="card-body">
          <form method = "post" action = "add_job.php">
            <div class="form-group">
              <div class="form-row">
               
				<div class="col-md-4">
                  <div class="form-group">
                    <input type="text"  class="form-control" placeholder="Job Title" name = "title" required="required"  autocomplete>
                  </div>
                </div>
				<div class="col-md-4">
                  <div class="form-group">

			     <select class="form-control" name="district" required = "required">
				<option value = "">Business District</option>
                  <?php foreach ($all_districts as $a_district ):
				  ?>
                   <option value="<?php echo $a_district['id'];?>"><?php echo ucwords($a_district['name']);?></option>
                <?php endforeach;?>
                </select>
			                  </div>
                </div>
				<div class="col-md-4">
                  <div class="form-group">
                    <input type="text"  class="form-control" placeholder="Location" name = "location" required="required" autocomplete >
                  </div>
                </div>
				
				<div class = "col-md-6">
                  <div class="form-group">
                    <button class = "btn btn-primary"  class="form-control" onclick = "insertDefaultJobDescription(); return false;"id = "defaultJobDescription">Insert Default Job Description</button>
                 </div>
				 </div>
				 
				  
         
				<div class="col-md-12">
                  <div class="form-group">
                    <textarea type="text"  class="form-control"  id = "jobDescription" placeholder="Job Description" name = "jobDescription"></textarea>
                  </div>
                </div>
				<div class = "col-md-6">
                  <div class="form-group">
                    <button class = "btn btn-primary"  class="form-control" onclick = "insertDefaultPersonSpecification(); return false;"id = "defaultJobDescription">Insert Default Person Specification</button>
                 </div>
				 </div>

                <div class="col-md-12">
                  <div class="form-group">
                    <textarea type="text"  class="form-control" id = "personSpecification" rows = "5" placeholder="Person Specification" name = "personSpecification"></textarea>
                  </div>
                </div>				
				
				
				
				<div class="col-md-4">
                  <div class="form-group">
                    <input type="text"  class="form-control" onfocus = "this.type = 'date'" placeholder="Pick Deadline" name = "deadline" required="required" >
                  </div>
                </div>
				
				<div class="col-md-4">
                  <div class="form-group">
                    <input type="number"  class="form-control" placeholder="No. of Agents" name = "agentCount" required="required" >
                  </div>
                </div>
					
                <div class="col-md-4">
                  <div class="form-label-group">
                            <button  name="submit_job" class="btn btn-primary pull-right"> Add Job</button>
                    </div>
                </div>
              </div>

            </div>

           
           
          </form>
         
        </div>
   
    </div>
	</div>
	</div>
    </div>
   </div>
    </div>
<script type = "text/javascript">
function insertDefaultPersonSpecification ()
{
	document.getElementById ('personSpecification').innerHTML = "This is the default person specification";
}

function insertDefaultJobDescription ()
{
	document.getElementById ('jobDescription').innerHTML = "To act as an our employee  in the area indicated ";
}


</script>