<?php 
require_once ('includes/load.php');
$page_title = 'Create User';
 page_require_level(3);
 $all_ug = find_all('user_groups');
 $all_dept = find_all('departments');
 ?>

 <?php
 if(isset($_POST['submit_user'])){
   $req_field = array('first_name', 'last_name', 'username', 'email_address', 'phone_number', 'department', 'user_group');
   validate_fields($req_field);
   $first_name = remove_junk($db->escape($_POST['first_name']));
   $last_name = remove_junk($db->escape($_POST['last_name']));
   $other_names = remove_junk($db->escape($_POST['other_names']));
   $title = remove_junk($db->escape($_POST['title']));
   $username= remove_junk($db->escape($_POST['username']));
   $email_address = remove_junk($db->escape($_POST['email_address']));
   $phone_number = remove_junk($db->escape($_POST['phone_number']));
   $department = remove_junk($db->escape($_POST['department']));
   $user_group = remove_junk($db->escape($_POST['user_group']));
   
   //create default password as a hash of first letter of lastname and full firstname
   
   $lower_surname = strtolower($last_name);
   
    $password = sha1($lower_surname);
   //end password creation 
   
   if(empty($errors)){
      $sql  = "INSERT INTO users (first_name, last_name, other_names, title,username, email_address, password, phone_number, department, user_level)";
      $sql .= " VALUES ('{$first_name}', '{$last_name}', '{$other_names}', '{$title}', '{$username}', '{$email_address}', '{$password}','{$phone_number}', '{$department}', '{$user_group}')";
      if($db->query($sql)){
		  insert_act('user', 'added', '1');
        $session->msg("s", "Successfully added user");
        redirect('manage_users.php',false);
      } else {
		  		  insert_act('user', 'added', '0');

        $session->msg("d", "Sorry failed to create user.");
        redirect('manage_users.php',false);
      }
   } else {
     $session->msg("d", $errors);
     redirect('manage_users.php',false);
   }
 }
?>
<?php include ('admin_header.php'); ?>


 <div class="container">
		     <?php echo display_msg($msg); ?>
 
      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Admin</a>
            </li>
            <li class="breadcrumb-item active">Manage Staff Accounts</li>
			
			</ol>

		  <!--start create user category -->
 <div class="card mb-3"  id = "add_uc">
        <div class="card-header"><i class = "fa fa-plus"></i> <i class = "fa fa-user"></i>  <span>Create a New User </span></div>
        <div class="card-body">
          <form method = "post" action = "add_user.php">
            <div class="form-group">
              <div class="form-row">
               
				<div class="col-md-4">
                  <div class="form-group">
                    <input type="text"  class="form-control" placeholder="First Name" name = "first_name" required="required" >
                  </div>
                </div>
				<div class="col-md-4">
                  <div class="form-group">
                    <input type="text"  class="form-control" placeholder="Last Name" name = "last_name" required="required" >
                  </div>
                </div>
				<div class="col-md-4">
                  <div class="form-group">
                    <input type="text"  class="form-control" placeholder="Other Names" name = "other_names">
                  </div>
                </div>
				<div class = "col-md-4">
                <select class="form-control" name="title">
				<option value = "">Title </option>
                   <option value="Mr">Mr</option>
				    <option value="Mrs">Mrs</option>
					 <option value="Dr">Dr</option>
					 <option value="Prof">Professor</option>
                </select>
				</div>
				<div class="col-md-4">
                  <div class="form-group">
                    <input type="text"  class="form-control" placeholder="Username" name = "username" required="required" >
                  </div>
                </div>
				<div class="col-md-4">
                  <div class="form-group">
                    <input type="email"  class="form-control" placeholder="Email" name = "email_address" required="required" >
                  </div>
                </div>
				<div class="col-md-4">
                  <div class="form-group">
                    <input type="phone"  class="form-control" placeholder="Phone" name = "phone_number" required="required" >
                  </div>
                </div>
				<div class = "col-md-4">
                <select class="form-control" name="department" required = "required">
				<option value = "">Select User Department </option>
                  <?php foreach ($all_dept as $a_ud ):?>
                   <option value="<?php echo $a_ud['id'];?>"><?php echo ucwords($a_ud['name']);?></option>
                <?php endforeach;?>
                </select>
				</div>
				<div class = "col-md-4">
                <select class="form-control" name="user_group" required = "required">
				<option value = "">Select User Group</option>
                  <?php foreach ($all_ug as $a_ug ):
				  $categoryInfo = find_by_id ('user_categories', $a_ug['category_level']);
				  $categoryName = $categoryInfo['group_name'];
				  ?>
                   <option value="<?php echo $a_ug['id'];?>"><?php echo ucwords($a_ug['group_name']. " ". $categoryName);?></option>
                <?php endforeach;?>
                </select>
				</div>
                <div class="col-md-4">
                  <div class="form-label-group">
                            <button  name="submit_user" class="btn btn-primary pull-right"> Add User</button>
                    </div>
                </div>
              </div>

            </div>
			<label  class="btn btn-warning disabled pull-right"> Note: The default password for a new user is their last name in lower case </button>

           
           
          </form>
         
        </div>
   
    </div>
	</div>
	</div>
	
	
		  
		  
		  <!-- end add user category -->
		  
		  

        </div>
        <!-- /.container-fluid -->

       

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
  
