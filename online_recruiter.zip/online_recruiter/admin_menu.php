 


      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="users.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Users</span>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-users"></i>
            <span>Applicants</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <h6 class="dropdown-header">Latest Applications:</h6>
            <a class="dropdown-item" href="login.html">Unprocessed</a>
            <a class="dropdown-item" href="register.html">Processed</a>
			<a class="dropdown-item" href="register.html"> <i class = "fa fa-paperclip"></i> <span>Documents</span></a>

]            <div class="dropdown-divider"></div>
            <h6 class="dropdown-header">X:</h6>
            <a class="dropdown-item" href="404.html">Y</a>
            <a class="dropdown-item" href="blank.html">Z</a>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="charts.html">
            <i class="fas fa-fw fa-list"></i>
            <span>To do list</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="tables.html">
            <i class="fas fa-fw fa-comments"></i>
            <span>Messages</span></a>
        </li>
      </ul>
	  